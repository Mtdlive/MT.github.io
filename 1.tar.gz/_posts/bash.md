---
title: Bash变量
index_img: 
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-21 14:19:54
hide: false
category_bar: true
categories:
  - linux
  - bash
tags:
  - bash
  - linux
sticky: 2
excerpt: 终端变量自定义及 vim 编辑器相关配置内容
---

# bashrc/vimrc

*d="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

*`vim /root/.vimrc`**
{% spoiler 代码折叠，点击展开 %}
````bash
set ignorecase
set cursorline
set autoindent
autocmd BufNewFile *.sh exec ":call SetTitle()"
func SetTitle()
	if expand("%:e") == 'sh'
	call setline(1,"#!/bin/bash")
	call setline(2,"###########################################")
	call setline(3,"#Author: Mxxxxxia                         ##")
	call setline(4,"#QQ： 1xxxxxxx59                          #####")
	call setline(5,"#Date： ".strftime("%Y-%m-%d               "))
	call setline(6,"#Mage Education:   Mxxxxxxxxx             ###############")
	call setline(7,"#FileName： ".expand("%"))
	call setline(8,"#URL： https://Mtdia.github.io            #####")
	call setline(9,"#Description： The test script            ##")
	call setline(10,"###########################################")
	call setline(11,"")
	endif
	endfunc
	autocmd BufNewFile * normal G

set hlsearch                    "文本文件中 vim 搜索关键词高亮显示
set clipboard=unnamed           " 设置vim中默认使用选择缓冲区寄存器,y复制,p粘贴
set pastetoggle=<F1>	        " 斩杀复制粘贴时产生的恶心的缩进
set ai                          " 自动缩进，新行与前面的行保持—致的自动空格
set cursorline                  " 显示光标行
set aw                          " 自动写，转入shell或使用：n编辑其他文件时，当前的缓冲区被写入
set flash                       " 在出错处闪烁但不呜叫(缺省)
set ic                          " 在查询及模式匹配时忽赂大小写
set number                      " 屏幕左边显示行号
set showmatch                   " 显示括号配对，当键入“]”“)”时，高亮度显示匹配的括号
set showmode                    " 处于文本输入方式时加亮按钮条中的模式指示器
set warn                        " 对文本进行了新的修改后，离开shell时系统给出显示(缺省)
set ws                          " 在搜索时如到达文件尾则绕回文件头继续搜索
set wrap                        " 长行显示自动折行
colorscheme evening             " 设定背景为夜间模式
filetype plugin on              " 自动识别文件类型，自动匹配对应的, “文件类型Plugin.vim”文件，使用缩进定义文件
set autoindent                  " 设置自动缩进：即每行的缩进值与上一行相等；使用 noautoindent 取消设置
set cindent                     " 以C/C++的模式缩进
set noignorecase                " 默认区分大小写
set ruler                       " 打开状态栏标尺
set scrolloff=5                 " 设定光标离窗口上下边界 5 行时窗口自动滚动
set shiftwidth=4                " 设定 << 和 >> 命令移动时的宽度为 4
set softtabstop=4               " 使得按退格键时可以一次删掉 4 个空格,不足 4 个时删掉所有剩下的空格）
set tabstop=4                   " 设定 tab 长度为 4
set wrap                        " 自动换行显示
syntax enable
syntax on                       " 自动语法高亮
set autoindent                  "自动对齐
set smartindent                 "智能对齐
set mouse=a                     "使用鼠标
"set mouse=v                    "使用鼠标选定复制
"inoremap ( ()<ESC>i            "括号自动补齐">
"inoremap [ []<ESC>i
"inoremap { {}<ESC>i
"inoremap < <><ESC>i
```
{% endspoiler %}
---
**`vim /root/.bashrc`**
{% spoiler 代码折叠，点击展开 %}
```bash
alias lll='ls -lAFhi'
alias ll='ls -lAFh'
alias l='ls -aF'
alias ld='ls -ldh'
alias la='ls -A'
alias cdd='cd /data/'
alias cde='cd /etc/'
alias cdh='cd /home/'

alias c=clear
alias d='date +%F/%X'
HISTTIMEFORMAT='%F %T  <====>  '
HISTIGNORE='ignoredups,ignorespace'
# PS1='\[\e[36;40m\][\u@\h \W]\$\e[m '  

# PS1='${debian_chroot:+($debian_chroot)}\[\033[01;31;1m\]\u\[\033[00;33;1m\]@\[\033[01;34;1m\]\h\[\033[00;33;1m\]:\[\033[00;32;1m\]\w \[\033[01;36;1m\]\$ \[\033[0;35;1m\]' 

# PS1='${debian_chroot:+($debian_chroot)}\[\033[0;35;1m\][\[\033[01;31;1m\]\u\[\033[00;33;1m\]@\[\033[01;34;1m\]\h\[\033[00;33;1m\]: \[\033[00;32;1m\]\w\[\033[0;35;1m\]]\033[01;36;1m\]\$ \[\033[0;35;3m\]'

PS1='${debian_chroot:+($debian_chroot)}\[\033[0;35;1m\]{\[\033[01;31;1m\]\u\[\033[00;33;1m\]@\[\033[01;34;1m\]\h\[\033[00;33;1m\]: \[\    033[00;32;1m\]\w \[\033[01;39;1m\]\A \[\033[0;35;1m\]}\[\033[01;36;1m\]\$ \[\033[01;36;1m\]==> \[\033[0;35;0m\]'
#PS1='${debian_chroot:+($debian_chroot)}\[\033[0;35;1m\][\[\033[01;31;1m\]\u\[\033[00;33;1m\]@\[\033[01;34;1m\]\h\[\033[00;33;1m\]: \[\033[00;32;1m\]\w \[\033[01;39;1m\]\A \[\033[0;35;1m\]]\[\033[01;36;1m\]\$ \[\033[01;36;1m\]==> \[\033[0;35;0m\]'
```
{% endspoiler %}
```bash
使文件生效
退出vim后，输入：source ~/.bashrc 或者 . ~./bashrc
```

---
{% spoiler 代码折叠，点击展开 %}
```html
颜色代码:
字背景颜色: 40–49 字体颜色: 30—39
40: 黑 　　　　　　 30: 黑
41: 红 　　　　　　 31: 红
42: 绿 　　　　　　 32: 绿
43: 黄 　　　　　　 33: 黄
44: 蓝 　　　　　　 34: 蓝
45: 紫 　　　　　　 35: 紫
46: 深绿 　　　　　　 36: 深绿
47: 白色 　　　　　　 37: 白色

ANSI控制码:
\033[0m 关闭所有属性
\033[1m 设置高亮度
\033[3m 斜体字符
\033[4m 下划线
\033[5m 闪烁
\033[7m 反显
\033[8m 消隐
\033[30m – \033[37m 设置前景色
\033[40m – \033[47m 设置背景色
\033[nA 光标上移n行
\03[nB 光标下移n行
\033[nC 光标右移n行
\033[nD 光标左移n行

默认的特殊符号所代表的意义：
\d ：代表日期，格式为weekday month date，例如：“Mon Aug 1”
\H ：完整的主机名称。例如：我的机器名称为：fc4.linux，则这个名称就是fc4.linux
\h ：仅取主机的第一个名字，如上例，则为fc4，.linux则被省略
\t ：显示时间为24小时格式，如：HH：MM：SS
\T ：显示时间为12小时格式
\A ：显示时间为24小时格式：HH：MM
\u ：当前用户的账号名称
\v ：BASH的版本信息
\w ：完整的工作目录名称。家目录会以 ~代替
\W ：利用basename取得工作目录名称，所以只会列出最后一个目录
# ：下达的第几个命令
$ ：提示字符，如果是root时，提示符为：# ，普通用户则为：$

echo -e "\033[32m输出绿色字符串\033[0m"
echo -e "\033[43;35m输出黄色背景绿色字符串\033[0m"
echo -e "\033[1;43;35m输出高亮黄色背景绿色字符串\033[0m"
echo -e "\033[5;43;35m输出闪烁黄色背景绿色字符串\033[0m"
```
{% endspoiler %}
