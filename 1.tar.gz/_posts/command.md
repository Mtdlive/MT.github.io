---
title: Linux基础命令
index_img: 
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-28 13:22:54
hide: false
category_bar: true
categories:
  - linux
tags:
  - linux
sticky: 1
excerpt: Linux基础命令介绍及使用范例等内容
---

# 基础命令

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

### grep

**grep : 分析一行信息，如果其中有我们需要的信息，就将该行拿出来.**

**常用参数:**

```bash
-i : 忽略大小写的不同
-n : 输出行号
-v : 反向选择，显示没有查找内容的行
-o : 与-v相反，只输出文件中匹配到的部分。
-A : <显示列数> 除了显示符合范本样式的那一行之外，并显示该行之后的内容。
-B : 在显示符合范本样式的那一行之外，并显示该行之前的内容。
-C : <显示列数>或-<显示列数>  除了显示符合范本样式的那一列之外，并显示该列之前后的内容。
-E : 将范本样式为延伸的普通表示法来使用，意味着使用能使用扩展正则表达式。
```

---

### sed

**sed是一种流编辑器，它是文本处理中非常中的工具，能够配合正则表达式使用.处理时，把当前处理的行存储在临时缓冲区中，称为“模式空间”（pattern space），接着用sed命令处理缓冲区中的内容，处理完成后，把缓冲区的内容送往屏幕。接着处理下一行，这样不断重复，直到文件末尾。文件内容并没有 改变，除非你使用重定向存储输出。Sed主要用来自动编辑一个或多个文件；简化对文件的反复操作；编写转换程序等。**

**常用選項** :

```bash
-n #不輸出模式空間内容到屏幕，即不自動打印(但sed自帶默認打印)
-e #多點編輯
-f /PATH/SCRIPT_FILE #從指定文件中讀取編輯脚本
-r #支持使用擴展正則表達式
-i #備份文件並原處編輯
```

**地址定界** :

```bash
1> 不給地址:對全文進行處理
    
2> 單地址:
  #:指定的行，$:最後一行
  /pattern/:被此處模式所能夠匹配到的每一行

3> 地址範圍:
  #,#
  #,+#
  /part1/,/part2/
  #,/part1/

4> ~:步進
  1~2奇數行
  2~2偶數行
```

**編輯命令** :

```bash
a [\]text #在指定行後面追加文本，支持使用\n實現多行追加。
i [\]text #在当前行上面插入文本。
c\ #把选定的行改为新的文本。
d #删除，删除选择的行。
D #删除模板块的第一行。
s #替换指定字符
h #拷贝模板块的内容到内存中的缓冲区。
H #追加模板块的内容到内存中的缓冲区。
g #获得内存缓冲区的内容，并替代当前模板块中的文本。
G #获得内存缓冲区的内容，并追加到当前模板块文本的后面。
l #列表不能打印字符的清单。
n #读取下一个输入行，用下一个命令处理新的行而不是用第一个命令。
N #追加下一个输入行到模板块后面并在二者间嵌入一个新行，改变当前行号码。
p #打印當前模式空間内容，追加到默認輸出之後。
P(大写) #打印模板块的第一行。
q #退出Sed。
b lable #分支到脚本中带有标记的地方，如果分支不存在则分支到脚本的末尾。
r file #从file中读行。
t label #if分支，从最后一行开始，条件一旦满足或者T，t命令，将导致分支到带有标号的命令处，或者到脚本的末尾。
T label #错误分支，从最后一行开始，一旦发生错误或者T，t命令，将导致分支到带有标号的命令处，或者到脚本的末尾。
w /path/file #保存模式匹配的行至指定文件。  
W /path/file #保存模式匹配的第一行至指定文件。    
! #模式空間中匹配行取反處理。  
= #為模式空間中的行打印行號。  
    # #把注释扩展到下一个换行符以前。
```
**sed替換標記** :

```bash
 s/// 查找替換，支持使用其他分割符，s@@@,s%%%,s###等
```

**替換標記** :

| 字  符       |                    表 达 含 义                    |
| ------------ | ------------------------------------------------- |
| g            | 行内全局替换                                      |
| p            | 顯示替換成功的行                                  |
| w /PATH/FILE | 將替換成功的行保存至文件中                        |
| x            | 互换模式空間中的文本和缓冲区中的文本              |
| y            | 把一个字符翻译为另外的字符（但是不用于正则表达式）|
| \\1          | 子串匹配标记                                      |
| &            | 已匹配字符串标记                                  |

**示例 :**
```bash
sed ‘2p’  /etc/passwd 
sed  -n ‘2p’ /etc/passwd 
sed  -n ‘1,4p’ /etc/passwd 
sed  -n ‘/root/p’  /etc/passwd 
sed  -n ‘2,/root/p’  /etc/passwd 从2行开始 
sed  -n ‘/^$/=’  file 显示空行行号 
sed  -n  -e ‘/^$/p’ -e ‘/^$/=’  file 
sed ‘/root/a\superman’  /etc/passwd行后 
sed ‘/root/i\superman’ /etc/passwd 行前 
sed ‘/root/c\superman’ /etc/passwd 代替行
```
```bash
sed ‘/^$/d’ file 
sed ‘1,10d’   file 
nl   /etc/passwd | sed ‘2,5d’ 
nl   /etc/passwd | sed ‘2a tea’ 
sed 's/test/mytest/g' example 
sed –n ‘s/root/&superman/p’ /etc/passwd 单词后 
sed –n ‘s/root/superman&/p’ /etc/passwd 单词前 
sed -e ‘s/dog/cat/’ -e ‘s/hi/lo/’ pets   
sed –i.bak  ‘s/dog/cat/g’ pets
```

**sed元字符集** :

| 字  符     | 表 达 含 义                   | 示 例                                                         |
| ---------- | ----------------------------- | ------------------------------------------------------------- |
| ^          | 匹配行开始                    | 如：/^sed/匹配所有以sed开头的行                               | 
| $          | 匹配行结束                    | 如：/sed$/匹配所有以sed结尾的行                               |
| .          | 匹配一个非换行符的任意字符    | 如：/s.d/匹配s后接一个任意字符，最后是d                       |
| \*         | 匹配0个或多个字符             | 如：/*sed/匹配所有模板是一个或多个空格后紧跟sed的行           |
| []         | 匹配一个指定范围内的字符      | 如/[ss]ed/匹配sed和Sed                                        |
| [^]        | 匹配一个不在指定范围内的字符  | 如：/[^A-RT-Z]ed/匹配不包含A-R和T-Z的一个字母开头，紧跟ed的行 |
| \\(..\\)   | 匹配子串，保存匹配的字符      | 如s/\(love\)able/\1rs，loveable被替换成lovers                 |
| &          | 保存搜索字符用来替换其他字符  | 如s/love/**&**/，love这成**love**                             |
| \\<        | 匹配单词的开始                | 如:/\<love/匹配包含以love开头的单词的行                       |
| \\>        | 配单词的结束                  | 如/love\>/匹配包含以love结尾的单词的行                        |
| x\\{m\\}   | 重复字符x，m次                | 如：/0\{5\}/匹配包含5个0的行                                  |
| x\\{m,\\}  | 重复字符x，至少m次            | 如：/0\{5,\}/匹配至少有5个0的行                               |
| x\\{m,n\\} | 重复字符x，至少m次，不多于n次 | 如：/0\{5,10\}/匹配5~10个0的行                                |


**高级编辑命令** :

```bash
P： #打印模式空间开端至\n内容，并追加到默认输出之前 
h:  #把模式空间中的内容覆盖至保持空间中 
H：#把模式空间中的内容追加至保持空间中 
g:  #从保持空间取出数据覆盖至模式空间
G：#从保持空间取出内容追加至模式空间
x:  #把模式空间中的内容与保持空间中的内容进行互换
n:  #读取匹配到的行的下一行覆盖至模式空间 
N：#读取匹配到的行的下一行追加至模式空间
d:  #删除模式空间中的行 
D：#如果模式空间包含换行符，则删除直到第一个换行符的模式空间中的文本， 并不会读取新的输入行，而使用合成的模式空间重新启动循环。如果模式空间 不包含换行符，则会像发出d命令那样启动正常的新循环
```

**示例** :

```bash
sed -n 'n;p' FILE 
sed '1!G;h;$!d' FILE 
sed‘N;D’FILE 
sed '$!N;$!D' FILE 
sed '$!d' FILE 
sed ‘G’ FILE 
sed ‘g’ FILE 
sed ‘/^$/d;G’ FILE 
sed 'n;d' FILE  
sed -n '1!G;h;$p' FILE
```

---

### tr :

**tr** ```命令可以对来自标准输入的字符进行替换、压缩和删除。它可以将一组字符变成另一组字符，经常用来编写优美的单行命令，作用很强大。```

**主要参数** ：

```bash
-c 或——complerment：取代所有不属于第一字符集的字符；
-d 或——delete：删除所有属于第一字符集的字符；
-s 或--squeeze-repeats：把连续重复的字符以单独一个字符表示；
-t 或--truncate-set1：先删除第一字符集较第二字符集多出的字符。
```

**示例** ：
**将输入字符由大写转换为小写**：

```bash
echo "HELLO WORLD" | tr 'A-Z' 'a-z'
hello world
```

**用tr压缩字符，可以压缩输入中重复的字符** ：

```bash
echo "thissss is      a text linnnnnnne." | tr -s ' sn'
this is a text line.
```

**tr可以使用的字符类** ：

| 字符       | 表达含义           |
| ---------- | ------------------ |
| [:alnum:]  | 字母和数字         |
| [:alpha:]  | 字母               |
| [:cntrl:]  | 控制（非打印）字符 |
| [:digit:]  | 数字               |
| [:graph:]  | 图形字符           |
| [:lower:]  | 小写字母           |
| [:print:]  | 可打印字符         |
| [:punct:]  | 标点符号           |
| [:space:]  | 空白字符           |
| [:upper:]  | 大写字母           |
| [:xdigit:] | 十六进制字符       |

---

**使用tr打印1加至100** ：
```bash
[root@CentOS8 data]# echo {1..100} > filethree.txt

[root@CentOS8 data]# cat filethree.txt 
1 2 3 4 5 6 7 8 9 10
[root@CentOS8 data]# tr ' ' '+' < filethree.txt > filefour.txt

[root@CentOS8 data]# cat filefour.txt 
1+2+3+4+5+6+7+8+9+10
```

**打印1至100的奇偶数集** ：

```bash
[root@CentOS8 data]# echo {0..50..2} （打印1到50的偶数集）
0 2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50

[root@CentOS8 data]# echo {1..50..2}  （打印1到50的奇数集）               
1 3 5 7 9 11 13 15 17 19 21 23 25 27 29 31 33 35 37 39 41 43 45 47 49
```

---

### tail：

**tail** ```命令用于输入文件中的尾部内容。tail命令默认在屏幕上显示指定文件的末尾10行。```

**常用选项** ：

```bash
-f ： #显示文件最新追加的内容。
-s<秒数>或——sleep-interal=<秒数> ： #与“-f”选项连用，指定监视文件变化时间隔的秒数；
-v ： #当有多个文件参数时，总是输出各个文件名；
```

**示例** ：

```bash
tail file #（显示文件file的最后10行）
tail +20 file #（显示文件file的内容，从第20行至文件末尾）
tail -f file #（时时监听文件file内容）
```

---

### head

* head命令用于显示文件的开头的内容。在默认情况下，head命令显示文件的头10行内容。

**常用选项** ：

```bash
-n<数字>：指定显示头部内容的行数；
-c<字符数>：指定显示头部内容的字符数；
-v：总是显示文件名的头信息；
-q：不显示文件名的头信息。

示例：
[root@CentOS1908 ~]# cat /etc/passwd |head -n1
root:x:0:0:root:/root:/bin/bash
[root@CentOS1908 ~]# cat /etc/passwd |head -c10
root:x:0:0
[root@CentOS1908 ~]#
```

**利用 head 和 tail 命令组合我们可以将文件的指定前x行 和后x行打印出来**

---

### cut

**cut : 从某一行信息中取出某部分我们想要的信息**
```常用：cut -d '分隔字符' -f field // 用于分隔字符```
```cut -c 字符范围```

**常用选项** ：
```bash
-d : 后面接分隔字符,通常与 -f 一起使用
-f : 根据-d 将信息分隔成数段，-f 后接数字 表示取出第几段
-c : 以字符为单位取出固定字符区间的信息
-n：与“-b”选项连用，不分割多字节字符；
-b：仅显示行中指定直接范围的内容；
```

* 示例：

```bash
# 打印/etc/passwd文件中以 : 为分隔符的第1个字段和第6个字段分别表示用户名和家目录
[root@izuf6i29flb2df231kt91hz /]# cat etc/passwd | cut -d ':' -f 1,6

# 打印/etc/passwd文件中每一行的前10个字符：
[root@izuf6i29flb2df231kt91hz /]# cat /etc/passwd | cut -c 1-10
```
**实际使用中，比cut更加方便的命令有awk和sed，但这并不妨碍我们学习多一种命令**

---

### sort

**文件进行排序，并将排序结果标准输出。sort命令既可以从特定的文件，也可以从stdin中获取输入。**

**常用选项** ：

```bash
-f ：忽略大小写的差异，例如A 与a 视为编码相同
-b ：忽略最前面的空格部分
-M ：以月份的名字来排序，例如JAN, DEC 等等的排序方法
-n ：使用『纯数字』进行排序默认是以文字型态来排序的)
-r ：反向排序
-u ：就是uniq ，相同的资料中，仅出现一行代表
-t ：分隔符号，预设是用[tab] 键来分隔
-k ：以那个区间(field) 来进行排序的意思
```

* 示例：

```bash
# 对/etc/passwd的账号进行排序
cat /etc/passwd | sort
adm:x:3:4:adm:/var/adm:/sbin/nologin
bin:x:1:1:bin:/bin:/sbin/nologin
chrony:x:998:996::/var/lib/chrony:/sbin/nologin
        
#取出/etc/passwd中用户及UID并输出指定分隔符，再以数字区间排序
awk -F:   '{printf "Username: %-24sUID:%d\n",$1,$3}'  /etc/passwd |sort -t":" -k 3 -n
Username: root                    UID:0
Username: bin                     UID:1
Username: daemon                  UID:2
Username: adm                     UID:3
Username: lp                      UID:4
Username: sync                    UID:5

#以行长度从小到大排序
awk '{print length(), $0 | "sort -n" }' filename.txt


#打印文件中的最长行和最短行
最短行：awk '(NR==1||length(min)>length()){min=$0}END{print min}'  filename.txt

最长行：awk '{if (length(max)<length()) max=$0}END{print max}'  filename.txt

#处理文件，按照第二列数字倒序排列打印
Filename.csv内容：
ky100-074,35%,ky100-087,7%
ky100-073,35%,ky100-085,7%
ky100-025,35%,ky100-084,7%
ky100-024,35%,ky100-083,7%
ky100-022,35%,ky100-082,7%
ky100-021,35%,ky100-081,7%

awk -F, -v OFS="" '{print $1,",",$2|"sort -rt\",\" -k2"}' filename.csv
```

---
### uniq

**统计文件行内容**

**常用选项** ：

```bash
-c或——count：在每列旁边显示该行重复出现的次数；
-d或--repeated：仅显示重复出现的行列；
-f<栏位>或--skip-fields=<栏位>：忽略比较指定的栏位；
-s<字符位置>或--skip-chars=<字符位置>：忽略比较指定的字符；
-u或——unique：仅显示出一次的行列；
-w<字符位置>或--check-chars=<字符位置>：指定要比较的字符。
```

* 示例：

```
# 统计各行在文件中出现的次数：
sort file.txt | uniq -c

#在文件中找出重复的行：
sort file.txt | uniq -d
```

---

### wc

**wc：用来计算数字。**

**常用选项** ：

```bash
-l或——lines：只显示列数；
-w或——words：只显示字数。
```

* 示例：

```bash
# 查看etc/passwd中有多少账号
cat /etc/passwd | wc -l
```

---

### split

**split：顾名思义，讲一个大文件依据文件大小或行数切割成为小文件**

**常用选项** ：

```bash
-b : 后面可接欲切割文件的大小，可加单位，例如b,k,m等
-l : 以行数来进行切割
-C：每一输出档中，单行的最大 byte 数。
-d：使用数字作为后缀。
```

* 示例：

```bash
#生成一个大小为100KB的测试文件：
[root@localhost split]# dd if=/dev/zero bs=100k count=1 of=date.file
1+0 records in
1+0 records out
102400 bytes (102 kB) copied, 0.00043 seconds, 238 MB/s

#使用split命令将上面创建的date.file文件分割成大小为10KB的小文件：
[root@localhost split]# split -b 10k date.file 
[root@localhost split]# ls
date.file  xaa  xab  xac  xad  xae  xaf  xag  xah  xai  xaj

#分割大的tar文件為多份小文件
split -b Size -d tar-file-name prefix-name
split -b 1M -d mybackup.tgz mybackup-parts
split -b 1M mybackup.tgz mybackup-parts
#合并切割的文件:
cat mybackup-parts* > mybackup-tar.gz

# 若你有一个超大的压缩包在服务器中，无法通过常规操作导出
# 你可以将其切割，导出后无需合并直接进行解压
split -b 2G -d tomcat.tar.gz tomcat.tar.gz.
cat tomcat.tar.gz.* | tar xzvf -
```

---

### I/O重定向：

**将输出和错误重新定向到文件**
![](https://img-blog.csdnimg.cn/20190928132109982.png)
**STDOUT和STDERR可以被重定向到文件**

**支持的操作符号包括**：

```bash
1> 把STDOUT重新定向到文件
2> 把STDERR重新定向到文件
&> 把所有输出重新定向到文件
```

```bash
>  #文件内容将会被覆盖
set -C  #禁止将内容覆盖已有文件，但可以追加
1> | file  #强制覆盖
set +C  #允许覆盖
>>  #在原有内容基础上，追加内容
2>  #覆盖重定向错误输出数据流
2>>  #追加重定向错误输出数据流
```

**标准输出和标准错误输出各自定向至不同位置：**

```bash
COMMAND > /path/to/file.out 2> /path/to/error.out
```

**合并标准输出和错误输出为同一个数据流进行重定向**


```bash
     &>  #覆盖重定向

    &>>  #追加重定向

COMMAND > /path/to/file.out 2>&1

        (顺序很重要)

COMMAND >> /path/to/file.out 2>&1

 #合并多个程序的STDOUT

  （cal 2007；cal 2008） > all.txt
```

### 命令执行过程视图：
![](https://img-blog.csdnimg.cn/2019092813215113.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

**示例：**

```bash
[root@Redhat7 data]# ls /home/ > file 
[root@Redhat7 data]# cat file 
td
[root@Redhat7 data]# ls /home/xsifuew 2> file 
[root@Redhat7 data]# cat file 
ls: cannot access /home/xsifuew: No such file or directory
[root@Redhat7 data]# ls /home/xsifuew 1> file 2>&1
[root@Redhat7 data]# cat file 
ls: cannot access /home/xsifuew: No such file or directory
```

**单行重定向：**

```bash
[root@CentOS8 data]# cat > ./file.txt
       abc
       def
       xyz
```

**多行重定向：**

   * 开始符与结束符为相同字符

```bash
[root@CentOS8 data]# cat > ./filetwo.txt <<开始符
      > abc
      > def
      > 结束符
```

---

### 管道命令：

**命令执行顺序控制**
* 通常情况下，我们在终端只能执行一条命令，然后按下回车执行，那么如何执行多条命令呢？

```bash
顺序执行多条命令：
command1;command2;command3;
简单的顺序指令可以通过 ;来实现
```

```bash
有条件的执行多条命令：
which command1 && command2 || command3

&& :  #如果前一条命令执行成功则执行下一条命令，如果command1执行成功（返回0）,则执行command2
|| :  #与&&命令相反，执行不成功时执行这个命令
$? :  #存储上一次命令的返回结果
```

---

### 标准错误导入管道 ：

```bash
[root@CentOS8 data]# xxx | tr 'a-z' 'A-Z'   #这样输入是无法将其导入的！     
bash: xxx: command not found...
Failed to search for file: Cannot update read-only repo

#正确做法：

[root@CentOS8 data]# xxx |& tr 'a-z' 'A-Z'
BASH: XXX: COMMAND NOT FOUND...
FAILED TO SEARCH FOR FILE: CANNOT UPDATE READ-ONLY REPO

#使用tr将其替换成大写并输出至文件中：

[root@CentOS8 data]# xxx |& tr 'a-z' 'A-Z' > filefive.txt

[root@CentOS8 data]# cat filefive.txt 
BASH: XXX: COMMAND NOT FOUND...
FAILED TO SEARCH FOR FILE: CANNOT UPDATE READ-ONLY REPO
```

---
