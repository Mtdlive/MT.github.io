---
title: MD
index_img: /img/md.png
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-20 08:13:54
hide: false
categories: 
- [md]
tags: md
sticky: 1
excerpt: md文件配置参考
password: Mtdia
abstract: 原文内容被加密了, 请输入密码查看.
message: 输入密码查看原文！
---

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

* 代码折叠

```txt
\       {% details 代码折叠，点击展开 %}
\       1. Sushi
\       2. Tempura
\       3. Sukiyaki
\       {% enddetails %}
```

```txt
\	{% details 代码折叠，点击展开 %}
\	```bash
\	1. Sushi
\	2. Tempura
\	3. Sukiyaki
\	```
\	{% enddetails %}
```

{% details 代码折叠，点击展开 %}
1. Sushi
2. Tempura
3. Sukiyaki
{% enddetails %}

{% details 代码折叠，点击展开 %}
```bash
1. Sushi
2. Tempura
3. Sukiyaki
```
{% enddetails %}

---

```txt
\       {% spoiler 代码折叠，点击展开 %}
\       1. Sushi
\       2. Tempura
\       3. Sukiyaki
\       {% endspoiler %}
```

```txt
\	{% spoiler 代码折叠，点击展开 %}
\	```bash
\	1. Sushi
\	2. Tempura
\	3. Sukiyaki
\	```
\	{% endspoiler %}
```

{% spoiler 代码折叠，点击展开 %}
1. Sushi
2. Tempura
3. Sukiyaki
{% endspoiler %}

{% spoiler 代码折叠，点击展开 %}
```bash
1. Sushi
2. Tempura
3. Sukiyaki
```
{% endspoiler %}

---

* 字体设置
```txt
<font face="微软雅黑" >微软雅黑字体</font>
<font face="黑体" >黑体</font>
font size=3 >3号字</font>
<font size=5 >5号字</font>
<font color=#FF0000 >红色</font>
<font color=#008000 >绿色</font>
<font color=#0000FF >蓝色</font>

red红色、orange橙色、yellow黄色、green绿色、blue蓝色、purple紫色
pink粉红色、brown棕色、white白色、black黑色、gray灰色、mauve紫红。

<table><tr><td bgcolor=orange> 我是橘色 orange</td></tr></table>
<table><tr><td bgcolor= BlueViolet >我是紫罗兰色</td></tr></table>
<table><tr><td bgcolor= red >我是红色</td></tr></table>
<table><tr><td bgcolor= yellow >我是黄色</td></tr></table>
<table><tr><td bgcolor= green >我是绿色</td></tr></table>
<table><tr><td bgcolor= blue >我是蓝色</td></tr></table>
<table><tr><td bgcolor= purple >我是紫色</td></tr></table>
<table><tr><td bgcolor= pink >我是粉红色</td></tr></table>
<table><tr><td bgcolor= brown >我是棕色</td></tr></table>
<table><tr><td bgcolor= white >我是白色</td></tr></table>
<table><tr><td bgcolor= black >我是黑色</td></tr></table>
<table><tr><td bgcolor= gray >我是灰色</td></tr></table>
<table><tr><td bgcolor= mauve >我是紫红色</td></tr></table>
```

<font face="微软雅黑" >微软雅黑字体</font>
<font face="黑体" >黑体</font>
<font size=3 >3号字</font>
<font size=5 >5号字</font>
<font color=#FF0000 >红色</font>
<font color=#008000 >绿色</font>
<font color=#0000FF >蓝色</font>


<table><tr><td bgcolor=orange> 我是橘色</td></tr></table>
<table><tr><td bgcolor= BlueViolet >我是紫罗兰色</td></tr></table>
<table><tr><td bgcolor= red >我是红色</td></tr></table>
<table><tr><td bgcolor= yellow >我是黄色</td></tr></table>
<table><tr><td bgcolor= green >我是绿色</td></tr></table>
<table><tr><td bgcolor= blue >我是蓝色</td></tr></table>
<table><tr><td bgcolor= purple >我是紫色</td></tr></table>
<table><tr><td bgcolor= pink >我是粉红色</td></tr></table>
<table><tr><td bgcolor= brown >我是棕色</td></tr></table>
<table><tr><td bgcolor= white >我是白色</td></tr></table>
<table><tr><td bgcolor= black >我是黑色</td></tr></table>
<table><tr><td bgcolor= gray >我是灰色</td></tr></table>
<table><tr><td bgcolor= mauve >我是紫红色</td></tr></table>

---

* 便签

```html
可选便签：
primary
secondary
success
danger
warning
info
light
```

使用 HTML 形式：
```txt
<p class="note note-primary">标签</p>
<p class="note note-secondary">标签</p>
<p class="note note-success">标签</p>
<p class="note note-danger">标签</p>
<p class="note note-warning">标签</p>
<p class="note note-info">标签</p>
<p class="note note-light">标签</p>
```

<p class="note note-primary">标签</p>
<p class="note note-secondary">标签</p>
<p class="note note-success">标签</p>
<p class="note note-danger">标签</p>
<p class="note note-warning">标签</p>
<p class="note note-info">标签</p>
<p class="note note-light">标签</p>


在 markdown 中加入如下的代码来使用便签：
文字 或者 `markdown` 均可
```txt
{% note primary %}
`markdown`
{% endnote %}

{% note secondary %}
*test123*
{% endnote %}

{% note success %}
test123
{% endnote %}

{% note danger %}
**test123**
{% endnote %}

{% note warning %}
`test123`
{% endnote %}

{% note info %}
[个人博客](https://mtdia.github.io/)
{% endnote %}

{% note info %}
![图片](https://mtdia.github.io/img/docker.png)
{% endnote %}

{% note light %}
# test123
{% endnote %}

{% note warning %}
# Warning
---
警告！
{% endnote %}
```

{% note primary %}
`markdown`
{% endnote %}

{% note secondary %}
*test123*
{% endnote %}

{% note success %}
`test123`
{% endnote %}

{% note danger %}
**test123**
{% endnote %}

{% note warning %}
`test123`
{% endnote %}

{% note info %}
[个人博客](https://mtdia.github.io/)
{% endnote %}

{% note info %}
![图片](https://mtdia.github.io/img/docker.png)
{% endnote %}

{% note light %}
# test123
{% endnote %}

{% note warning %}
# Warning
---
警告！
{% endnote %}

---

* 勾选框

```md
{% cb text, checked?, incline? %}
```

```txt
text：显示的文字
checked：默认是否已勾选，默认 false
incline: 是否内联（可以理解为后面的文字是否换行），默认 false
```

**`示例：`**
{% cb 网络正常, true %}
{% cb 内存足够,true %}
{% cb Docker安装,true %}

```txt
{% cb 网络正常, true %}
{% cb 内存足够,true %}
{% cb Docker安装,true %}
```

---

* 按钮

**可以在 markdown 中加入如下的代码来使用 Button：**

```md
{% btn url, text, title %}
```

**或者使用 HTML 形式：**

```md
<a class="btn" href="url" title="title">text</a>
```

```txt
url：跳转链接
text：显示的文字
title：鼠标悬停时显示的文字（可选）
```

**`示例：`**
{% btn https://mtdia.github.io, 博客, 我的博客 %}

<a class="btn" href="https://mtdia.github.io/" title="我的博客">博客</a>

```txt
{% btn https://mtdia.github.io, 博客, 我的博客 %}

<a class="btn" href="https://mtdia.github.io/" title="我的博客">博客</a>
```


---

| 字符       | 表达含义           |
| ---------- | ------------------ |
| [:alnum:]  | 字母和数字         |
| [:alpha:]  | 字母               |
| [:cntrl:]  | 控制字符           |
| [:digit:]  | 数字               |
| [:graph:]  | 图形字符           |
| [:lower:]  | 小写字母           |
| [:print:]  | 可打印字符         |
| [:punct:]  | 标点符号           |
| [:space:]  | 空白字符           |
| [:upper:]  | 大写字母           |
| [:xdigit:] | 十六进制字符       |


```txt
| 字符       | 表达含义           |
| ---------- | ------------------ |
| [:alnum:]  | 字母和数字         |
| [:alpha:]  | 字母               |
| [:cntrl:]  | 控制字符           |
| [:digit:]  | 数字               |
| [:graph:]  | 图形字符           |
| [:lower:]  | 小写字母           |
| [:print:]  | 可打印字符         |
| [:punct:]  | 标点符号           |
| [:space:]  | 空白字符           |
| [:upper:]  | 大写字母           |
| [:xdigit:] | 十六进制字符       |
```
