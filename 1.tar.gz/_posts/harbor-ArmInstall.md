---
title: harbor Arm架构部署
index_img: /img/harbor.png
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-12-09 09:24:54
hide: false
category_bar: true
categories:
  - kylin
  - docker
tags:
  - kylin
  - docker
sticky: 5
excerpt: harbor Arm架构安装操作流程
password: Mtdia
abstract: 原文内容被加密了, 请输入密码查看.
message: 输入密码查看原文！
---

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

# harbor Arm架构部署

**由于目前harbor官方暂未支持arm架构部署安装，因此不得不另辟蹊径安装部署**

<a class="btn" href="https://pan.baidu.com/s/141UItDc5h5va0vV4dFWUXg?pwd=4uxi" title="点击下载">harbor-arrch64-v1.10.1 提取码: 4uxi</a>

{% note success %}
## 注意！
---
1. 该压缩包仅在arm架构,银河麒麟服务器中经过测试！
2. 请提前安装docker-ce服务，并确保docker版本>=1903且服务正常运行！
3. 请确保daemon.json已配置私有镜像仓库信息
cat /etc/docker/daemon.json 
{
  "insecure-registries": ["x.x.x.x:8086","harbor:8086"],
}
   确保已配置hosts解析
cat /etc/hosts
x.x.x.x harbor

4. 将压缩包下载上传至服务器，解压后将生成两个目录
5. 请进入images目录执行1.sh 导入镜像
6. 请进入install目录将docker-compose文件移动至 /usr/bin/
7. 修改install目录下harbor.yml文件配置
8. 最后执行install.sh进行安装harbor服务
{% endnote %}

---

**若你的确是需要自己手动重新编译，进行部署arm架构下的harbor服务**
**下方提供本人编译部署的全部过程，注意我所用的环境为银河麒麟服务器**
**相关信息：4.19.90-24.4.v2101.ky10.aarch64**

```bash
# 以下为我本人编译部署全过程
# github harbor部署包下载
https://github.com/mytting/harbor-arm64

## 执行以下命令，创建基础目录，下载部署包
mkdir /data/harbor/{data,logs}
cd /data/harbor/
wget https://codeload.github.com/mytting/harbor-arm64/zip/refs/heads/main
unzip main
cd harbor-arm64-main

# 以下三条命令执行时间较长，请耐性等待1-2个小时
# build基础镜像
# 执行过程有可能会报错终止，重复执行，并在执行结束后执行 echo $? 若输出为 0 则执行下一步
make build_base_docker

# build镜像
# 执行过程有可能会报错终止，重复执行，并在执行结束后执行 echo $? 若输出为 0 则执行下一步
make build

# 打包harbor
# 执行过程有可能会报错终止，重复执行
# 本人在实际执行过程中，前两条都已多次执行后成功，但最后一条命令在最后报了一个错误
# 我在多次重复执行后依旧报错，最后跳过这条报错，进行部署harbor也成功了
make package_offline

# 报错信息如下：
Removing intermediate container 8662816b7939
 ---> 7414e35f2d96
Successfully built 7414e35f2d96
Successfully tagged goharbor/chartmuseum-photon:v1.10.1
Done.
make[1]: 离开目录“/data/harbor/harbor-arm64-main”
packing offline package ...
saving harbor docker image
Error response from daemon: reference does not exist
make: *** [Makefile:355：package_offline] 错误 1

[root@Kylin harbor-arm64-main]# echo $?
2


# 执行后续部署操作
cd /data/harbor/harbor-arm64-main/harbor/
vim harbor.yml
# harbor.yml配置参考如下:
[root@Kylin harbor]# egrep -v "^#|^$|^( ){1,}#" harbor.yml 
hostname: 123.123.123.123
http:
  port: 11880
harbor_admin_password: Kylin123123.
database:
  password: Kylin123123.
  max_idle_conns: 50
  max_open_conns: 100
data_volume: /data/harbor/data
clair:
  updaters_interval: 12
jobservice:
  max_job_workers: 10
notification:
  webhook_job_max_retry: 10
chart:
  absolute_url: disabled
log:
  level: info
  local:
    rotate_count: 50
    rotate_size: 200M
    location: /data/harbor/logs
_version: 1.10.0
proxy:
  http_proxy:
  https_proxy:
  no_proxy:
  components:
    - core
    - jobservice
    - clair


# 继续执行后续操作
./prepare
# 确保 ./prepare 执行结果没有报错
./install.sh
# ./install.sh 脚本最终的输出结果如下：
[Step 4]: starting Harbor ...
Creating network "harbor_harbor" with the default driver
Creating harbor-log ... done
Creating redis         ... done
Creating registryctl   ... done
Creating harbor-db     ... done
Creating registry      ... done
Creating harbor-portal ... done
Creating harbor-core   ... done
Creating harbor-jobservice ... done
Creating nginx             ... done
✔ ----Harbor has been installed and started successfully.----
[root@Kylin harbor]# echo $?
0

# 配置docker私有仓库
[root@Kylin harbor]# cat /etc/docker/daemon.json 
{
  "registry-mirrors": ["https://dl0ygawi.mirror.aliyuncs.com"],
  "insecure-registries": ["123.123.123.123:11880"]
}

# 重启docker
systemctl daemon-reload && systemctl restart docker

# 重启完docker有可能harbor部分容器停止后并未启动，手动启动一次
cd /data/harbor/harbor-arm64-main/harbor/
[root@Kylin harbor]# docker-compose up -d
harbor-log is up-to-date
Starting redis ... 
Starting harbor-db ... 
Starting redis     ... done
Starting harbor-db ... done
Starting registry  ... done
harbor-core is up-to-date
harbor-jobservice is up-to-date
Starting nginx     ... done
# 终端登录仓库
[root@Kylin harbor]# docker login 123.123.123.123:11880
Username: admin
Password: 
WARNING! Your password will be stored unencrypted in /root/.docker/config.json.

# 网页访问仓库地址
http://123.123.123.123:11880

# harbor相关容器
[root@Kylin harbor]# docker ps|grep goharbor
32c46fd4ee55        goharbor/harbor-jobservice:v1.10.1               "/harbor/harbor_jobs…"   About an hour ago   Up About an hour (healthy)                                                                             harbor-jobservice
faa45a5acc07        goharbor/nginx-photon:v1.10.1                    "nginx -g 'daemon of…"   About an hour ago   Up About an hour (healthy)   0.0.0.0:11880->8080/tcp                                                   nginx
5a96f4dc2a95        goharbor/harbor-core:v1.10.1                     "/harbor/harbor_core"    About an hour ago   Up About an hour (healthy)                                                                             harbor-core
878f1155448a        goharbor/harbor-portal:v1.10.1                   "nginx -g 'daemon of…"   About an hour ago   Up About an hour (healthy)   8080/tcp                                                                  harbor-portal
31da018a8279        goharbor/registry-photon:v1.10.1                 "/home/harbor/entryp…"   About an hour ago   Up About an hour (healthy)   5000/tcp                                                                  registry
bca5e0027e92        goharbor/harbor-db:v1.10.1                       "/docker-entrypoint.…"   About an hour ago   Up About an hour (healthy)   5432/tcp                                                                  harbor-db
cfeb1bce6b9c        goharbor/harbor-registryctl:v1.10.1              "/home/harbor/start.…"   About an hour ago   Up About an hour (healthy)                                                                             registryctl
745b0a26107c        goharbor/redis-photon:v1.10.1                    "redis-server /etc/r…"   About an hour ago   Up About an hour (healthy)   6379/tcp                                                                  redis
031325c2b965        goharbor/harbor-log:v1.10.1                      "/bin/sh -c /usr/loc…"   About an hour ago   Up About an hour (healthy)   127.0.0.1:1514->10514/tcp                                                 harbor-log

# 备注：
# 在编译过程中，可能会出现异常报错，而重复执行一次后又正常了
# 编译过程只要没有结束，就不需要手动干预，等待执行结束就好
# 编译过程中会频繁访问GitHub，网络问题可能会导致其不断超时，等待其不断访问重试即可，无需手动干预
# 目前银河麒麟服务器harbor仓库配置及数据存放目录如下：
# docker-compose.yml及harbor.yml文件
/data/harbor/harbor-arm64-main/harbor/
# 数据及日志
/data/harbor/{data,logs}
```
