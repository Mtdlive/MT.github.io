---
title: Gitlab容器部署
index_img: /img/gitlab.png
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-26 10:20:54
hide: false
category_bar: true
categories:
  - docker
  - gitlab
tags:
  - gitlab
  - docker
sticky: 4
excerpt: Docker部署Gitlab

---

# 容器部署Gitlab

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

```txt
准备一台CentOS7虚拟机，可ping通外网，基础环境自配，默认已安装 Docker 服务
```

[Docker服务部署步骤](https://mtdia.github.io/2022/10/20/CentOS7.4-Docker1903/)

---

### 部署步骤

{% spoiler 代码折叠，点击展开 %}
```bash
# 配置docker国内阿里加速
[root@gitlab gitlab]# cat /etc/docker/daemon.json
{
  "registry-mirrors": ["https://dl0ygawi.mirror.aliyuncs.com"]
}

# 不要忘记将docker服务加入开机自启
[root@gitlab gitlab]# systemctl daemon-reload && sudo systemctl restart docker
[root@gitlab gitlab]# systemctl --now enable docker

# 查看docker 版本
[root@gitlab gitlab]# docker -v
Docker version 20.10.18, build b40c2f6

# 当前所在目录
[root@gitlab gitlab]# pwd
/data/gitlab

# 有关gitlab的其他镜像可以前往docker.hub官网进行下载
# gitlab容器运行脚本
[root@gitlab gitlab]# cat gitlab-run.sh 
#!/bin/bash
docker run -d \
-p 10008:80 -p 10009:443 -p 10010:22 \
--restart always \
--name gitlab \
-v /data/gitlab/etc/gitlab:/etc/gitlab \
-v /data/gitlab/log/gitlab:/var/log/gitlab \
-v /data/gitlab/opt/gitlab:/var/opt/gitlab \
--privileged=true drud/gitlab-ce:v0.29.1

# 运行脚本，拉取镜像耗时较长
[root@gitlab gitlab]# bash gitlab-run.sh 
······过程省略

# 查看gitlab镜像
[root@gitlab gitlab]# docker images
REPOSITORY       TAG       IMAGE ID       CREATED       SIZE
drud/gitlab-ce   v0.29.1   3e5f92380a64   3 years ago   1.44GB

# 查看正在运行的容器
[root@gitlab gitlab]# docker ps -a
CONTAINER ID   IMAGE                    COMMAND             CREATED        STATUS                  PORTS                                                                                                                         NAMES
394451ec2c94   drud/gitlab-ce:v0.29.1   "/assets/wrapper"   41 hours ago   Up 41 hours (healthy)   0.0.0.0:10010->22/tcp, :::10010->22/tcp, 0.0.0.0:10008->80/tcp, :::10008->80/tcp, 0.0.0.0:10009->443/tcp, :::10009->443/tcp   gitlab
```
{% endspoiler %}

![gitlab_config](/img/gitlab_config.png)

{% spoiler 代码折叠，点击展开 %}
```bash
# 修改gitlab配置文件，参考上图追加以下内容
[root@gitlab gitlab]# vim etc/gitlab/gitlab.rb
# 如果没有域名，则直接使用宿主机的ip; 但若服务使用了 nginx 转发 则此处必须写nginx所在的虚拟机IP
external_url 'http://113.x.x.184'
# 如果没有域名，则直接使用宿主机的ip; 但若服务使用了 nginx 转发 则此处必须写nginx所在的虚拟机IP
gitlab_rails['gitlab_ssh_host'] = '113.x.x.184'
# 端口为启动docker时映射的ssh端口
gitlab_rails['gitlab_shell_ssh_port'] =10010
# 设置时区为东八区，即北京时间
gitlab_rails['time_zone'] = 'Asia/Shanghai'

# 邮件配置
gitlab_rails['smtp_enable'] = true
gitlab_rails['smtp_address'] = "smtp.qq.com"   # 邮箱服务器
gitlab_rails['smtp_port'] = 465    # 邮箱服务对应的端口号
gitlab_rails['smtp_user_name'] = "16xxxxxxxx9@qq.com"   # 发件箱的邮箱地址
gitlab_rails['smtp_password'] = "ymxxxxxxxxxxxxce"      # 发件箱对应的授权码，注意不是登录密码，是授权码
gitlab_rails['smtp_domain'] = "qq.com"
gitlab_rails['smtp_authentication'] = "login"
gitlab_rails['smtp_enable_starttls_auto'] = true
gitlab_rails['smtp_tls'] = true
gitlab_rails['gitlab_email_enabled'] = true
gitlab_rails['gitlab_email_from'] = '16xxxxxxxxx9@qq.com'     # 发件箱地址
gitlab_rails['gitlab_email_display_name'] = 'fxxxxxy'    # 显示名称
gitlab_rails['gitlab_email_reply_to'] = '16xxxxxxxx9@qq.com'     # 给指定邮箱发送邮件提示不要回复
```
{% endspoiler %}

### 配置邮件

* 登录QQ邮箱网页端-设置-账户-开启POP3/SMTP服务

  

![mail-2](/img/mail-1.png)

![mail-1](/img/mail-2.png)

![gitlab_config-2](/img/gitlab_config-2.png)

{% spoiler 代码折叠，点击展开 %}
```bash
# 将gitlab容器删了，重新运行
[root@gitlab gitlab]# docker stop gitlab && docker rm gitlab
[root@gitlab gitlab]# bash gitlab-run.sh

# 进入 gitlab容器，参考上图修改配置文件
[root@gitlab gitlab]# docker exec -it gitlab bash
root@394451ec2c94:/# vi /opt/gitlab/embedded/service/gitlab-rails/config/gitlab.yml
# 如果没有域名，则直接使用宿主机的ip; 但若服务使用了 nginx 转发 则此处必须写nginx所在的虚拟机IP
    host: 113.x.x.184
# 若服务使用了 nginx 转发 则此处必须写nginx转发的端口，若未配置 nginx 转发 则写容器外部映射端口 10008
    port: 10880
    https: false
# 如果没有域名，则直接使用宿主机的ip; 但若服务使用了 nginx 转发 则此处必须写nginx所在的虚拟机IP
    ssh_host: 113.x.x.184

# 在容器中重启gitlab
root@394451ec2c94:/# gitlab-ctl restart
········过程省略
```
{% endspoiler %}

### 浏览器访问

* 若服务使用了 nginx 转发 则访问nginx转发的IP:端口，若未配置 nginx 转发 则访问虚拟机本机IP:10008
* 首次登录需要重置密码

![gitlab_wab-1](/img/gitlab_wab-1.png)

* 默认账户：root

![gitlab_wab-2](/img/gitlab_wab-2.png)

* 关闭gitlab的注册功能

  ![gitlab_wab-3](/img/gitlab_wab-3.png)

* 取消勾选

  ![gitlab_wab-4](/img/gitlab_wab-4.png)

* 退出重新登录，注册选项已去除

  ![gitlab_wab-5](/img/gitlab_wab-5.png)

* 用户创建及组创建便不再进行操作
