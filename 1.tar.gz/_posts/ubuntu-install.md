---
title: Ubuntu安装
index_img: /img/ubuntu.png
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-20 14:06:54
hide: false
category_bar: true
categories:
  - linux
tags:
  - linux
sticky: 1
excerpt: Ubuntu 虚拟机安装操作流程
---

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

@[toc]

**Ubuntu 1804-server 下载**
![](https://img-blog.csdnimg.cn/20191228083326655.png)


**Ubuntu 1904-server 下载**
![](https://img-blog.csdnimg.cn/20191228083350180.png)

[ubuntu server(服务器版)](http://cdimage.ubuntu.com/releases/)  

[ubuntu desktop(桌⾯版)](http://releases.ubuntu.com/)

[vmware workstations15下载链接 提取码: bnih](https://pan.baidu.com/s/1ll8Y7oAUKoeTf3xHY450LA)

## 安装步骤(开始)：

1
![](https://img-blog.csdnimg.cn/20191228084311521.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
2
![](https://img-blog.csdnimg.cn/20191228084320970.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
3
![](https://img-blog.csdnimg.cn/20191228084323397.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
4
![](https://img-blog.csdnimg.cn/201912280843381.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
5
![](https://img-blog.csdnimg.cn/20191228084347637.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
6
![](https://img-blog.csdnimg.cn/20191228084354151.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
7
![](https://img-blog.csdnimg.cn/2019122808440570.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
8
![](https://img-blog.csdnimg.cn/20191228084413157.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
9
![](https://img-blog.csdnimg.cn/20191228084419596.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
10
![](https://img-blog.csdnimg.cn/20191228084438224.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
11
![](https://img-blog.csdnimg.cn/20191228084446623.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
12
![](https://img-blog.csdnimg.cn/20191228084454135.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
13
![](https://img-blog.csdnimg.cn/20191228084501855.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
14
![](https://img-blog.csdnimg.cn/20191228084514110.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
15
![](https://img-blog.csdnimg.cn/20191228084520361.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
16
![](https://img-blog.csdnimg.cn/20191228084530290.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
17
![](https://img-blog.csdnimg.cn/20191228084543748.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
18
![](https://img-blog.csdnimg.cn/20191228084551166.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
19
![](https://img-blog.csdnimg.cn/20191228084600736.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
20
![](https://img-blog.csdnimg.cn/20191228084603927.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
21
![](https://img-blog.csdnimg.cn/20191228084615839.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
22
![](https://img-blog.csdnimg.cn/20191228084623971.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
23
![](https://img-blog.csdnimg.cn/20191228084631432.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
24
![](https://img-blog.csdnimg.cn/20191228084633648.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
25
![](https://img-blog.csdnimg.cn/20191228084649953.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
26
![](https://img-blog.csdnimg.cn/2019122808465951.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
27
![](https://img-blog.csdnimg.cn/20191228084712172.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
28
![](https://img-blog.csdnimg.cn/20191228084723918.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
29
![](https://img-blog.csdnimg.cn/20191228084732301.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
30
![](https://img-blog.csdnimg.cn/20191228084740309.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
31
![](https://img-blog.csdnimg.cn/20191228084748146.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
32
![](https://img-blog.csdnimg.cn/201912280847551.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
33
![](https://img-blog.csdnimg.cn/20191228084805287.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
34
![](https://img-blog.csdnimg.cn/20191228084816399.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
35
![](https://img-blog.csdnimg.cn/20191228084822942.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
36
![](https://img-blog.csdnimg.cn/20191228084833129.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
37
![](https://img-blog.csdnimg.cn/20191228084841495.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
38
![](https://img-blog.csdnimg.cn/20191228084846620.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
39
![](https://img-blog.csdnimg.cn/20191228084901330.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
40
![](https://img-blog.csdnimg.cn/20191228084907900.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
41
![](https://img-blog.csdnimg.cn/20191228084916639.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
42
![](https://img-blog.csdnimg.cn/20191228084929924.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
43
![](https://img-blog.csdnimg.cn/20191228084936704.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
44
![](https://img-blog.csdnimg.cn/20191228084943893.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
45
![](https://img-blog.csdnimg.cn/2019122808495182.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
46

## 安装步骤(结束)：
#重启虚拟机
#基础配置

student@U:~$ sudo -i
sudo: unable to resolve host U
[sudo] password for td: 
[root@U ~]# 

---
[root@U ~]# echo '127.0.0.1 U8' >> /etc/hosts
[root@U ~]# echo 'U8' > /etc/hostname

---

```bash
[root@U8 ~]# vim /root/.bashrc
#追加以下内容
################# Custom Alias ############
alias c=clear
alias d='date +%F/%X'
HISTTIMEFORMAT='%F %T  <====>  '
HISTIGNORE='ignoredups,ignorespace'
PS1='\[\e[36;40m\][\u@\h \W]\$\e[m ' 
```
[root@U8 ~]# . /root/.bashrc 

---
```bash
[root@U8 ~]# vim /root/.vimrc 
set ignorecase
set cursorline                                                                                    
set autoindent
autocmd BufNewFile *.sh exec ":call SetTitle()"                                                           
func SetTitle()
if expand("%:e") == 'sh'
call setline(1,"#!/bin/bash")
call setline(2,"###########################################")
call setline(5,"#Date： ".strftime("%Y-%m-%d               "))
call setline(6,"#************:   *********             ###############")
call setline(7,"#FileName： ".expand("%"))
call setline(10,"###########################################")
call setline(11,"")
endif
endfunc
autocmd BufNewFile * normal G

#######更便利的使用 vim #####若不想使用某功能即在该行首加 " 即可#########
set clipboard=unnamed           " 设置vim中默认使用选择缓冲区寄存器,y复制,p粘贴
set pastetoggle=<F1>	        " 斩杀复制粘贴时产生的恶心的缩进
set ai                          " 自动缩进，新行与前面的行保持—致的自动空格
set cursorline                  " 显示光标行
set aw                          " 自动写，转入shell或使用：n编辑其他文件时，当前的缓冲区被写入
set flash                       " 在出错处闪烁但不呜叫(缺省)
set ic                          " 在查询及模式匹配时忽赂大小写
"set number                      " 屏幕左边显示行号
set showmatch                   " 显示括号配对，当键入“]”“)”时，高亮度显示匹配的括号
set showmode                    " 处于文本输入方式时加亮按钮条中的模式指示器
set warn                        " 对文本进行了新的修改后，离开shell时系统给出显示(缺省)
set ws                          " 在搜索时如到达文件尾则绕回文件头继续搜索
set wrap                        " 长行显示自动折行
colorscheme evening             " 设定背景为夜间模式
filetype plugin on              " 自动识别文件类型，自动匹配对应的, “文件类型Plugin.vim”文件，使用缩进定义文件
set autoindent                  " 设置自动缩进：即每行的缩进值与上一行相等；使用 noautoindent 取消设置
set cindent                     " 以C/C++的模式缩进
set noignorecase                " 默认区分大小写
set ruler                       " 打开状态栏标尺
set scrolloff=5                 " 设定光标离窗口上下边界 5 行时窗口自动滚动
set shiftwidth=4                " 设定 << 和 >> 命令移动时的宽度为 4
set softtabstop=4               " 使得按退格键时可以一次删掉 4 个空格,不足 4 个时删掉所有剩下的空格）
set tabstop=4                   " 设定 tab 长度为 4
set wrap                        " 自动换行显示
syntax enable
syntax on                       " 自动语法高亮
set autoindent                  "自动对齐
set smartindent                 "智能对齐
"set mouse=a                     "使用鼠标
"set mouse=v                    "使用鼠标选定复制
"inoremap ( ()<ESC>i            "括号自动补齐">
"inoremap [ []<ESC>i
"inoremap { {}<ESC>i
"inoremap < <><ESC>i
```

---

```bash
# 修改网卡名称为eth0
[root@U9 ~]# vim /etc/default/grub
GRUB_DEFAULT=0
GRUB_TIMEOUT_STYLE=hidden
GRUB_TIMEOUT=2
GRUB_DISTRIBUTOR=\`lsb_release -i -s 2> /dev/null || echo Debian`
GRUB_CMDLINE_LINUX_DEFAULT=""
GRUB_CMDLINE_LINUX="net.ifnames=0 biosdevname=0"
```

[root@U9 ~]# update-grub
Sourcing file `/etc/default/grub'
Sourcing file `/etc/default/grub.d/init-select.cfg'
Generating grub configuration file ...
Found linux image: /boot/vmlinuz-5.0.0-13-generic
Found initrd image: /boot/initrd.img-5.0.0-13-generic
done

#修改静态IP（空格有严格要求）：
[root@U ~]# vim /etc/netplan/01-netcfg.yaml
```bash
#内容如下：
network:
  version: 2
  renderer: networkd
  ethernets:
    eth0:
      addresses: [192.168.124.7/24]
      gateway4: 192.168.124.10
      dhcp4: no
      nameservers:
       addresses: [8.8.8.8]
```
#使用vim编辑文件时，可使用该命令阻止递进
:set paste

[root@U ~]# netplan apply
[root@U ~]# ping www.baidu.com
测试能否ping通外部网络；若通即完成

---
Ubuntu无法使用xshell连接如何操作：
[root@U ~]# apt install openssh-server
[root@U ~]# service ssh start

---
Ubuntu无法使用scp传输文件如何操作：
[root@U ~]# vim /etc/ssh/sshd_config 
PermitRootLogin yes

---
Ubuntu无法使用root在Xshell直接登录如何操作：
[root@U ~]# vim /etc/ssh/sshd_config 
#追加此行

PasswordAuthentication yes

---
一定要记得修改文件后，重启服务

#重启服务
[root@U ~]# /etc/init.d/ssh restart
[ ok ] Restarting ssh (via systemctl): ssh.service.

---
## Ubuntu软件源配置
```bash
[root@U ~]# cd /etc/apt/
[root@U apt]# cp sources.list sources.list.backup
[root@U apt]# vim sources.list
#追加以下所有内容

#默认注释了源码镜像以提高 apt update 速度，如有需要可自行取消注释
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-updates main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-updates main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-backports main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-backports main restricted universe multiverse
deb https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-security main restricted universe multiverse
# deb-src https://mirrors.tuna.tsinghua.edu.cn/ubuntu/ bionic-security main restricted universe multiverse
 
```
## 常用软件包安装
```bash
apt install iproute2 ntpdate tcpdump telnet traceroute nfs-kernel-server \
nfs-common lrzsz tree openssl libssl-dev libpcre3 libpcre3-dev zlib1g-dev \
ntpdate tcpdump telnet traceroute gcc openssh-server iotop unzip zip make -y
```

