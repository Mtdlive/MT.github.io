---
title: Docker部署
index_img: /img/docker.png
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-24 10:13:54
hide: false
category_bar: true
categories:
  - docker
tags:
  - docker
sticky: 4
excerpt: CentOS7 Docker服务部署、命令使用及容器管理等相关操作
---

# **CentOS 7.4 - Docker 19.03**

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

[TOC]

![](/img/docker.png)

#### docker安装

{% spoiler 代码折叠，点击展开 %}
````bash
#卸载原虚拟机中旧版本Docker
sudo yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine
           
#安装yum-utils包（提供yum-config-manager 实用程序）并设置国内稳定存储库。（官网配置为国外地址，速度慢）
sudo yum install -y yum-utils
sudo yum-config-manager \
    --add-repo \
    http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
    
#安装指定版本Docker
sudo yum install docker-ce-19.03.5 docker-ce-cli-19.03.5 containerd.io

#列出并排序您的存储库中可用的Docker版本
yum list docker-ce --showduplicates | sort -r

#镜像加速
#先执行以下命令，查看是否在 docker.service 文件中配置过镜像地址
systemctl cat docker | grep '\-\-registry\-mirror'

#如果该命令有输出，那么执行 systemctl cat docker 查看 ExecStart= 出现的位置，修改对应的文件内容去掉 --registry-mirror 参数及其值，并按接下来的步骤进行配置

#如果以上命令没有任何输出，那么就可以在 /etc/docker/daemon.json 中写入如下内容
vim /etc/docker/daemon.json
{
  "registry-mirrors": [
    "https://hub-mirror.c.163.com",
    "https://mirror.baidubce.com"
  ]
}

#重新启动服务
sudo systemctl daemon-reload && sudo systemctl restart docker

#启动Docker,并开机自启
sudo systemctl start docker
sudo systemctl enable docker

#查看Docker版本
docker -v

#通过运行hello-world 映像验证 Docker Engine 是否已正确安装
sudo docker run hello-world
#内容输出信息：
Unable to find image 'hello-world:latest' locally
latest: Pulling from library/hello-world
b8dfde127a29: Pull complete 
Digest: sha256:0fe98d7debd9049c50b597ef1f85b7c1e8cc81f59c8d623fcb2250e8bec85b38
Status: Downloaded newer image for hello-world:latest

Hello from Docker!		#输出此信息表示Docker已正常运行
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.

To try something more ambitious, you can run an Ubuntu container with:
 $ docker run -it ubuntu bash

Share images, automate workflows, and more with a free Docker ID:
 https://hub.docker.com/

For more examples and ideas, visit:
 https://docs.docker.com/get-started/
 
 #查看已有镜像
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
hello-world         latest              d1165f221234        5 months ago        13.3kB

````
{% endspoiler %}
---
#### 启动容器
{% spoiler 代码折叠，点击展开 %}
```bash
#Docker启动镜像
#查看可下载的nginx镜像有哪些
[root@docker ~]# docker search nginx

#下载nginx-1.16版本镜像
[root@docker ~]# docker pull nginx:1.16

#查看刚下载的nginx镜像
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
hello-world         latest              d1165f221234        5 months ago        13.3kB
nginx               1.16                dfcfd8e9a5d3        15 months ago       127MB

#运行nginx镜像，运行分为两种方式：
#-d ：后台运行   
#-it : 交互式运行
#--name : 给启动的镜像命名
[root@docker ~]# docker run -d --name nginx-test01 dfcfd8e9a5d3
891162d04f1244cd618fccdf24d1382dd1e794834ec9ee22f682a2d6aebbe58e

#查看正在运行的容器
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED              STATUS              PORTS               NAMES
891162d04f12        dfcfd8e9a5d3        "nginx -g 'daemon of…"   About a minute ago   Up About a minute   80/tcp              nginx-test01

#进入后台运行的容器
[root@docker ~]# docker exec -it 891162d04f12 /bin/bash
root@891162d04f12:/# ls
bin  boot  dev	etc  home  lib	lib64  media  mnt  opt	proc  root  run  sbin  srv  sys  tmp  usr  var

#停止容器
[root@docker ~]# docker stop 891162d04f12
891162d04f12
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES

#运行容器
[root@docker ~]# docker start 891162d04f12
891162d04f12
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS               NAMES
891162d04f12        dfcfd8e9a5d3        "nginx -g 'daemon of…"   5 minutes ago       Up 3 seconds        80/tcp              nginx-test01

#删除容器
#删除运行中的容器/已停止的容器
[root@docker ~]# docker run -d --name nginx-test02 dfcfd8e9a5d3
15e778a5bb491aa18e6aa2e29783f591489a59be927e4da99cd9809df4871ac3
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS               NAMES
15e778a5bb49        dfcfd8e9a5d3        "nginx -g 'daemon of…"   7 seconds ago       Up 6 seconds        80/tcp              nginx-test02
891162d04f12        dfcfd8e9a5d3        "nginx -g 'daemon of…"   8 minutes ago       Up 4 minutes        80/tcp              nginx-test01
[root@docker ~]# docker stop 891162d04f12
891162d04f12
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS               NAMES
15e778a5bb49        dfcfd8e9a5d3        "nginx -g 'daemon of…"   25 seconds ago      Up 24 seconds       80/tcp              nginx-test02

#以下信息可知：已停止的容器可以直接删除，而正在运行中的容器不能直接删除
[root@docker ~]# docker rm 891162d04f12
891162d04f12
[root@docker ~]# docker rm 15e778a5bb49
Error response from daemon: You cannot remove a running container 15e778a5bb491aa18e6aa2e29783f591489a59be927e4da99cd9809df4871ac3. Stop the container before attempting removal or force remove


#强制删除正在运行中的容器
[root@docker ~]# docker rm -f 15e778a5bb49
15e778a5bb49

#列出所有容器ID
#-a ：查询本机所有的容器，不管容器是否在运行
#-qa ：列出所有的容器ID
[root@docker ~]# docker ps -qa
0142d564b60a
8416fc8c0973

#强制删除所有容器
[root@docker ~]# docker rm -f $(docker ps -qa)
0142d564b60a
8416fc8c0973
[root@docker ~]# docker ps -qa
[root@docker ~]# 

#删除镜像
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
hello-world         latest              d1165f221234        5 months ago        13.3kB
nginx               1.16                dfcfd8e9a5d3        15 months ago       127MB
[root@docker ~]# docker rmi d1165f221234
Untagged: hello-world:latest
Untagged: hello-world@sha256:0fe98d7debd9049c50b597ef1f85b7c1e8cc81f59c8d623fcb2250e8bec85b38
Deleted: sha256:d1165f2212346b2bab48cb01c1e39ee8ad1be46b87873d9ca7a4e434980a7726
Deleted: sha256:f22b99068db93900abe17f7f5e09ec775c2826ecfe9db961fea68293744144bd
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               1.16                dfcfd8e9a5d3        15 months ago       127MB

#批量删除镜像
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
hello-world         latest              d1165f221234        5 months ago        13.3kB
nginx               1.16                dfcfd8e9a5d3        15 months ago       127MB
[root@docker ~]# docker images -qa
d1165f221234
dfcfd8e9a5d3
[root@docker ~]# docker rmi $(docker images -qa)
Untagged: nginx:1.16
Untagged: nginx@sha256:d20aa6d1cae56fd17cd458f4807e0de462caf2336f0b70b5eeb69fcaaf30dd9c
Deleted: sha256:dfcfd8e9a5d38fb82bc8f9c299beba2df2232b7712b62875d5238cead7a5831c
Deleted: sha256:d02bd10c7ab368ff7c09eae1c0ac63b139cdd909d035c2acf15dbdfec2324c26
Deleted: sha256:444aa1698480236e67460ed344a57863965a03bb389d2478a137c97147b50765
Deleted: sha256:c2adabaecedbda0af72b153c6499a0555f3a769d52370469d8f6bd6328af9b13
Error response from daemon: conflict: unable to delete d1165f221234 (must be forced) - image is being used by stopped container 0ffef7c89201
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
hello-world         latest              d1165f221234        5 months ago        13.3kB

#由此可知，正在被使用的镜像是不能直接删除的，必须先删除以该镜像运行的容器，再删除镜像
[root@docker ~]# docker ps -qa
0ffef7c89201
[root@docker ~]# docker rm -f $(docker ps -qa)
0ffef7c89201
[root@docker ~]# docker ps -qa
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
hello-world         latest              d1165f221234        5 months ago        13.3kB
[root@docker ~]# docker rmi $(docker images -qa)
Untagged: hello-world:latest
Untagged: hello-world@sha256:0fe98d7debd9049c50b597ef1f85b7c1e8cc81f59c8d623fcb2250e8bec85b38
Deleted: sha256:d1165f2212346b2bab48cb01c1e39ee8ad1be46b87873d9ca7a4e434980a7726
Deleted: sha256:f22b99068db93900abe17f7f5e09ec775c2826ecfe9db961fea68293744144bd
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE

```
{% endspoiler %}
---
#### 容器部署nginx
{% spoiler 代码折叠，点击展开 %}
```bash
#Docker启动nginx镜像并测试访问
[root@docker ~]# docker pull nginx:1.16
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               1.16                dfcfd8e9a5d3        15 months ago       127MB

#后台运行nginx，并配置端口映射
#-p ：端口映射	主机端口:容器端口
[root@docker ~]# docker run -d --name nginx-test03 -p 8888:80 dfcfd8e9a5d3
[root@docker ~]# curl localhost:8888
<!DOCTYPE html>
<html>
<head>
<title>Welcome to nginx!</title>
...........

#停止nginx容器，重新测试访问
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                  NAMES
802cf357ac21        dfcfd8e9a5d3        "nginx -g 'daemon of…"   10 minutes ago      Up 10 minutes       0.0.0.0:8888->80/tcp   nginx-test03
[root@docker ~]# docker stop 802cf357ac21
802cf357ac21
[root@docker ~]# curl localhost:8888
curl: (7) Failed connect to localhost:8888; Connection refused

             1.16                dfcfd8e9a5d3        15 months ago       127MB

```
{% endspoiler %}
---

#### 镜像导入导出
{% spoiler 代码折叠，点击展开 %}
```bash
#镜像导出与导入
#镜像导出
[root@docker ~]# docker images 
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               1.16                dfcfd8e9a5d3        15 months ago       127MB
[root@docker ~]# docker save -o /data/nginx.tar nginx:1.16
[root@docker ~]# ll -h /data/
total 125M
-rw------- 1 root root 125M Aug 14 16:25 nginx.tar

#镜像导入
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               1.16                dfcfd8e9a5d3        15 months ago       127MB
[root@docker ~]# docker ps -qa
[root@docker ~]# docker rmi dfcfd8e9a5d3
Untagged: nginx:1.16
Untagged: nginx@sha256:d20aa6d1cae56fd17cd458f4807e0de462caf2336f0b70b5eeb69fcaaf30dd9c
Deleted: sha256:dfcfd8e9a5d38fb82bc8f9c299beba2df2232b7712b62875d5238cead7a5831c
Deleted: sha256:d02bd10c7ab368ff7c09eae1c0ac63b139cdd909d035c2acf15dbdfec2324c26
Deleted: sha256:444aa1698480236e67460ed344a57863965a03bb389d2478a137c97147b50765
Deleted: sha256:c2adabaecedbda0af72b153c6499a0555f3a769d52370469d8f6bd6328af9b13
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE 
[root@docker ~]# docker load -i /data/nginx.tar 
c2adabaecedb: Loading layer [==================================================>]  72.49MB/72.49MB
82068c842707: Loading layer [==================================================>]  58.02MB/58.02MB
c23548ea0b99: Loading layer [==================================================>]  3.584kB/3.584kB
Loaded image: nginx:1.16
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               1.16                dfcfd8e9a5d3        15 months ago       127MB
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
[root@docker ~]# docker run -it --name nginx-test04 dfcfd8e9a5d3 /bin/bash 
root@6eb86872540d:/# ls
bin  boot  dev	etc  home  lib	lib64  media  mnt  opt	proc  root  run  sbin  srv  sys  tmp  usr  var

#交互状态下进入容器，exit退出后容器将随之释放，若想退出容器且容器仍继续运行，可使用 Ctrl + q + p 组合键退出
#退出后使用 exec 可重新进入容器
[root@docker ~]# docker exec -it 4669926e89e9 /bin/bash
root@4669926e89e9:/# exit
exit
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
4669926e89e9        dfcfd8e9a5d3        "/bin/bash"         3 minutes ago       Up 3 minutes        80/tcp              nginx-test05
```
{% endspoiler %}
---

### Docker-compose安装
{% spoiler 代码折叠，点击展开 %}
```bash
#终端命令下载可能会很慢，因此也可以在网页中下载好上传
[root@docker ~]# sudo curl -L https://github.com/docker/compose/releases/download/v2.2.2/docker-compose-linux-x86_64 >/usr/local/bin/docker-compose

#添加执行权限
[root@docker ~]# sudo chmod +x /usr/local/bin/docker-compose

#查看版本
[root@docker ~]# docker-compose -v
Docker Compose version v2.2.2

#事先下载好一个tomcat镜像
[root@docker ~]# docker pull tomcat:8.0
8.0: Pulling from library/tomcat
1aea3d9a32e6: Pull complete 
Digest: sha256:8ecb10948deb32c34aeadf7bf95d12a93fbd3527911fa629c1a3e7823b89ce6f
Status: Downloaded newer image for tomcat:8.0
docker.io/library/tomcat:8.0
[root@docker ~]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
tomcat              8.0                 ef6a7c98d192        3 years ago         356MB

[root@docker ~]# mkdir -p /data/docker/
[root@docker ~]# cd /data/docker/

#编辑第一个docker compose文件
[root@docker docker]# vim docker-compose.yml
version: "3.6"
services:
        tomcat:		#名称保持唯一
                image: tomcat:8.0		#镜像名称:tag
                ports:
                        - "8080:8080"		#映射 主机端口:容器端口
                        
#运行docker compose时要确保当前路径下有docker-compose.yml文件
#使用docker-compose up 可启动所有
#而使用 -f 选项可选择只运行指定的docker-compose.yml文件
[root@docker docker]# docker-compose -f docker-compose.yml up
[+] Running 2/2
 ⠿ Network docker_default     Created                                                                                 0.1s
 ⠿ Container docker-tomcat-1  Created                                                                                 0.0s
Attaching to docker-tomcat-1

#另开一个终端，访问页面正常
[root@docker docker]# curl http://192.168.40.30:8080
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <title>Apache Tomcat/8.0.53</title>
        <link href="favicon.ico" rel="icon" type="image/x-icon" />
        <link href="favicon.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="tomcat.css" rel="stylesheet" type="text/css" />
    </head>
.......................................

#当之前运行docker compose文件的终端被ctrl +c后，访问便会立刻失败
..............................
docker-tomcat-1  | 29-Dec-2021 00:31:55.585 INFO [main] org.apache.catalina.startup.Catalina.start Server startup in 1470 ms
^CGracefully stopping... (press Ctrl+C again to force)
[+] Running 1/1
 ⠿ Container docker-tomcat-1  Stopped                                                                                                                                                     0.8s
canceled

[root@docker docker]# curl http://192.168.40.30:8080
curl: (7) Failed connect to 192.168.40.30:8080; Connection refused
```
{% endspoiler %}
---
### Docker-compose运行多个服务
{% spoiler 代码折叠，点击展开 %}
```bash
#运行多个服务
[root@docker docker]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
tomcat              8.0                 ef6a7c98d192        3 years ago         356MB
[root@docker docker]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS               NAMES
[root@docker docker]# docker pull nginx:1.18
1.18: Pulling from library/nginx
f7ec5a41d630: Pull complete  
Digest: sha256:e90ac5331fe095cea01b121a3627174b2e33e06e83720e9a934c7b8ccc9c55a0
Status: Downloaded newer image for nginx:1.18
docker.io/library/nginx:1.18

[root@docker docker]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               1.18                c2c45d506085        8 months ago        133MB
tomcat              8.0                 ef6a7c98d192        3 years ago         356MB

[root@docker docker]# vim docker-compose.yml
version: "3.6"
services:
        tomcat:
                image: tomcat:8.0
                ports:
                        - "8080:8080"
        nginx:
                image: nginx:1.18
                ports:
                        - "80:80"
                        
[root@docker docker]# docker-compose up
[+] Running 2/0
 ⠿ Container docker-nginx-1   Created                                                                                                                                                     0.0s
 ⠿ Container docker-tomcat-1  Created                                                                                                                                                     0.0s
Attaching to docker-nginx-1, docker-tomcat-1
...............................


#在另外一个终端查看正在运行的容器信息
[root@docker docker]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                    NAMES
e37bba3b9afb        nginx:1.18          "/docker-entrypoint.…"   28 seconds ago      Up 25 seconds       0.0.0.0:80->80/tcp       docker-nginx-1
2baa4522c182        tomcat:8.0          "catalina.sh run"        18 minutes ago      Up 25 seconds       0.0.0.0:8080->8080/tcp   docker-tomcat-1

#访问测试正常
[root@docker docker]# curl http://192.168.40.30:8080
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100 11266    0 11266    0     0  76423      0 --:--:-- --:--:-- --:--:-- 76121
.................................
[root@docker docker]# curl http://192.168.40.30:80
  % Total    % Received % Xferd  Average Speed   Time    Time     Time  Current
                                 Dload  Upload   Total   Spent    Left  Speed
100   612  100   612    0     0   492k      0 --:--:-- --:--:-- --:--:--  597k
........................................

```
{% endspoiler %}
---
### compose映射路径启动服务
{% spoiler 代码折叠，点击展开 %}
```bash
#绝对路径映射
[root@docker docker]# vim docker-compose02.yml
version: "3.6"
services:
        tomcat:
                image: tomcat:8.0
                ports:
                        - "8080:8080"
                volumes:
                        - /data/docker/file:/data
                        
#运行
[root@docker docker]# docker-compose -f docker-compose02.yml up
WARN[0000] Found orphan containers ([docker-nginx-1]) for this project. If you removed or renamed this service in your compose file, you can run this command with the --remove-orphans flag to clean it up. 
[+] Running 1/1
 ⠿ Container docker-tomcat-1  Recreated                                                                                                                                                   0.1s
Attaching to docker-tomcat-1

#在另一个终端查看
[root@docker docker]# echo "123" >> /data/docker/file/1.txt
[root@docker docker]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS                    NAMES
4c4424faccc6        tomcat:8.0          "catalina.sh run"   2 minutes ago       Up 2 minutes        0.0.0.0:8080->8080/tcp   docker-tomcat-1
[root@docker docker]# docker exec -it 4c bash
root@4c4424faccc6:/usr/local/tomcat# cat /data/1.txt 
123

#自定义路径映射
[root@docker docker]# vim docker-compose02.yml
version: "3.6"
services:
        tomcat:
                image: tomcat:8.0
                ports:
                        - "8080:8080"
                volumes:
                        - testfile:/data	#自定义路径映射
volumes:	#声明上面服务使用的自定义卷名
        testfile:	#所声明的卷名名称，compose在创建此卷名时会在其名称前加上项目名(compose文件父目录名称)
        
#运行
[root@docker docker]# docker-compose -f docker-compose02.yml up
WARN[0000] Found orphan containers ([docker-nginx-1]) for this project. If you removed or renamed this service in your compose file, you can run this command with the --remove-orphans flag to clean it up. 
[+] Running 2/2
 ⠿ Volume "docker_testfile"   Created                                                                                                                                                     0.0s
 ⠿ Container docker-tomcat-1  Recreated                                                                                                                                                   0.1s
Attaching to docker-tomcat-1

#在另外一个终端查看正在运行的容器信息
[root@docker docker]# docker ps
CONTAINER ID        IMAGE               COMMAND             CREATED             STATUS              PORTS                    NAMES
5d8a5e39d85a        tomcat:8.0          "catalina.sh run"   4 minutes ago       Up 4 minutes        0.0.0.0:8080->8080/tcp   docker-tomcat-1
[root@docker docker]# docker exec -it 5d bash
root@5d8a5e39d85a:/usr/local/tomcat# cd /data/
root@5d8a5e39d85a:/data# ls
root@5d8a5e39d85a:/data# echo "123" >> 2.txt
root@5d8a5e39d85a:/data# exit
exit
[root@docker docker]# find / -name "2.txt"
/var/lib/docker/volumes/docker_testfile/_data/2.txt
```
{% endspoiler %}
---
### name
{% spoiler 代码折叠，点击展开 %}
```bash
[root@docker docker]# vim docker-compose02.yml
version: "3.6"
services:
        tomcat:
                image: tomcat:8.0
                ports:
                        - "8080:8080"
                volumes:
                        - tomcatfile:/data
                container_name: tomcat1229
        nginx:
                image: nginx:1.18
                ports:
                        - "80:80"
                volumes:
                        - nginxfile:/data
                container_name: nginx1229
volumes:
        tomcatfile:
        nginxfile:
       
#启动
[root@docker docker]# docker-compose -f docker-compose02.yml up
[+] Running 4/4
 ⠿ Volume "docker_tomcatfile"  Created                                                                                0.0s
 ⠿ Volume "docker_nginxfile"   Created                                                                                0.0s
 ⠿ Container docker-nginx-1    Recreated                                                                              0.1s
 ⠿ Container docker-tomcat-1   Recreated                                                                              0.1s
Attaching to nginx1229, tomcat1229

#在另外一个终端查看正在运行的容器信息
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                    NAMES
033ebdb662a1        nginx:1.18          "/docker-entrypoint.…"   17 seconds ago      Up 15 seconds       0.0.0.0:80->80/tcp       nginx1229
20152b550379        tomcat:8.0          "catalina.sh run"        17 seconds ago      Up 15 seconds       0.0.0.0:8080->8080/tcp   tomcat1229

[root@docker ~]# docker exec -it 033ebdb662a1 bash
root@033ebdb662a1:/# curl http://tomcat1229:8080
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
...................

#网络
[root@docker docker]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
nginx               1.18                c2c45d506085        8 months ago        133MB
tomcat              8.0                 ef6a7c98d192        3 years ago         356MB

[root@docker docker]# vim docker-compose02.yml 
version: "3.6"
services:
        tomcat:
                image: tomcat:8.0
                ports:
                        - "28080:8080"
                volumes:
                        - tomcatfile:/usr/local/tomcat
                container_name: tomcat1229
                networks:
                        - docker_test
        nginx:
                image: nginx:1.18
                ports:
                        - "280:80"
                volumes:
                        - nginxfile:/usr/local/nginx
                container_name: nginx1229
                networks:
                        - docker_test
        mysql:
                image: mysql:5.7
                ports:
                        - "23306:3306"
                volumes:
                        - mysqlfile:/usr/local/mysql
                container_name: mysql1229
                networks:
                        - docker_test
volumes:
        tomcatfile:
        nginxfile:
        mysqlfile:
networks:
        docker_test:
        
#启动，mysql的镜像会在启动compose时自动帮我们下载        
[root@docker docker]# docker-compose -f docker-compose02.yml up
[+] Running 12/12
 ⠿ mysql Pulled                                                                       115.3s
   ⠿ 72a69066d2fe Pull complete                                                        19.1s
   ⠿ 70deed891d42 Pull complete                                                       110.9s
[+] Running 5/5
 ⠿ Network docker_docker_test  Created                                                  0.1s
 ⠿ Volume "docker_mysqlfile"   Created                                                  0.0s
 ⠿ Container mysql1229         Created                                                  0.4s
 ⠿ Container tomcat1229        Recreated                                                0.6s
 ⠿ Container nginx1229         Recreated                                                0.4s
Attaching to mysql1229, nginx1229, tomcat1229
#数据库并未成功启动，因为未设置密码
mysql1229   | 2021-12-29 02:26:38+00:00 [ERROR] [Entrypoint]: Database is uninitialized and password option is not specified
mysql1229   |     You need to specify one of the following:
mysql1229   |     - MYSQL_ROOT_PASSWORD
mysql1229   |     - MYSQL_ALLOW_EMPTY_PASSWORD
mysql1229   |     - MYSQL_RANDOM_ROOT_PASSWORD
mysql1229 exited with code 1

#在另外一个终端查看正在运行的容器信息
[root@docker docker]# docker images
REPOSITORY          TAG                 IMAGE ID            CREATED             SIZE
mysql               5.7                 c20987f18b13        8 days ago          448MB
nginx               1.18                c2c45d506085        8 months ago        133MB
tomcat              8.0                 ef6a7c98d192        3 years ago         356MB
[root@docker docker]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                     NAMES
5f2f958be986        nginx:1.18          "/docker-entrypoint.…"   5 minutes ago       Up 5 minutes        0.0.0.0:280->80/tcp       nginx1229
3122d3ed7bce        tomcat:8.0          "catalina.sh run"        5 minutes ago       Up 5 minutes        0.0.0.0:28080->8080/tcp   tomcat1229

#根据报错提示，修改mysql的配置
[root@docker docker]# vim docker-compose02.yml 

version: "3.6"
services:
        tomcat:
                image: tomcat:8.0
                ports:
                        - "28080:8080"
                volumes:
                        - tomcatfile:/usr/local/tomcat
                container_name: tomcat1229
                networks:
                        - docker_test
        nginx:
                image: nginx:1.18
                ports:
                        - "280:80"
                volumes:
                        - nginxfile:/usr/local/nginx
                container_name: nginx1229
                networks:
                        - docker_test
        mysql:
                image: mysql:5.7
                ports:
                        - "23306:3306"
                volumes:
                        - mysqlfile:/usr/local/mysql
                container_name: mysql1229
                networks:
                        - docker_test
                environment:	#添加两行
                        - MYSQL_ROOT_PASSWORD=123456
volumes:
        tomcatfile:
        nginxfile:
        mysqlfile:
networks:
        docker_test:
        
        
#重新启动
[root@docker docker]#  docker-compose -f docker-compose02.yml up
[+] Running 3/3
 ⠿ Container nginx1229   Running                                                                                                                                                          0.0s
 ⠿ Container mysql1229   Recreated                                                                                                                                                        0.2s
 ⠿ Container tomcat1229  Running                                                                                                                                                          0.0s
Attaching to mysql1229, nginx1229, tomcat1229

#在另外一个终端查看正在运行的容器信息
[root@docker docker]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED              STATUS              PORTS                                NAMES
1d67e25b7c2d        mysql:5.7           "docker-entrypoint.s…"   About a minute ago   Up 11 seconds       33060/tcp, 0.0.0.0:23306->3306/tcp   mysql1229
5f2f958be986        nginx:1.18          "/docker-entrypoint.…"   13 minutes ago       Up 11 seconds       0.0.0.0:280->80/tcp                  nginx1229
3122d3ed7bce        tomcat:8.0          "catalina.sh run"        13 minutes ago       Up 11 seconds       0.0.0.0:28080->8080/tcp              tomcat1229

[root@docker docker]# docker exec -it 1d bash
root@1d67e25b7c2d:/# mysql -uroot -p123456
mysql: [Warning] Using a password on the command line interface can be insecure.
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 2
mysql> exit


[root@docker docker]# docker volume ls
DRIVER              VOLUME NAME
local               7d8a5c7ba17941d823509bb5485d300a751926847da6ecf48c18e8e47929901f
local               docker_mysqlfile
local               docker_nginxfile
local               docker_tomcatfile

[root@docker docker]# docker inspect docker_mysqlfile
[
    {
        "CreatedAt": "2021-12-29T10:26:36+08:00",
        "Driver": "local",
        "Labels": {
            "com.docker.compose.project": "docker",
            "com.docker.compose.version": "2.2.2",
            "com.docker.compose.volume": "mysqlfile"
        },
        "Mountpoint": "/var/lib/docker/volumes/docker_mysqlfile/_data",
        "Name": "docker_mysqlfile",
        "Options": null,
        "Scope": "local"
    }
]

```
{% endspoiler %}
---

### env_file
{% spoiler 代码折叠，点击展开 %}
```bash
#之前配置mysql虽然成功启动服务，但存在一个安全隐患（配置文件中的内容暴露了mysql的登录密码）
#因此可将 environment 改为另一种写法，使其将密码隐藏在文件中
[root@docker docker]# cat docker-compose02.yml 
version: "3.6"
services:
.........#其他服务配置省略不写，以下为原mysql配置内容
        mysql:
                image: mysql:5.7
                ports:
                        - "23306:3306"
                volumes:
                        - mysqlfile:/usr/local/mysql
                container_name: mysql1229
                networks:
                        - docker_test
                environment:
                        - MYSQL_ROOT_PASSWORD=123456
volumes:
        tomcatfile:
        nginxfile:
        mysqlfile:
networks:
        docker_test:
        
        
[root@docker docker]# vim mysql.env
MYSQL_ROOT_PASSWORD=123456

[root@docker docker]# vim docker-compose02.yml 

version: "3.6"
services:
.........#其他服务配置省略不写，以下为mysql修改后的配置内容
        mysql:
                image: mysql:5.7
                ports:
                        - "23306:3306"
                volumes:
                        - mysqlfile:/usr/local/mysql
                container_name: mysql1229
                networks:
                        - docker_test
                #environment:
                #        - MYSQL_ROOT_PASSWORD=123456
                env_file:
                        - mysql.env
volumes:
        tomcatfile:
        nginxfile:
        mysqlfile:
networks:
        docker_test:
        
        
[root@docker docker]# docker-compose -f docker-compose02.yml up
[+] Running 3/3
 ⠿ Container tomcat1229  Created                                                                                      0.0s
 ⠿ Container nginx1229   Created                                                                                      0.0s
 ⠿ Container mysql1229   Recreated                                                                                    0.2s
Attaching to mysql1229, nginx1229, tomcat1229


#在另外一个终端查看正在运行的容器信息
[root@docker ~]# docker ps
CONTAINER ID        IMAGE               COMMAND                  CREATED             STATUS              PORTS                                NAMES
acb4983f2d6c        mysql:5.7           "docker-entrypoint.s…"   2 minutes ago       Up 2 minutes        33060/tcp, 0.0.0.0:23306->3306/tcp   mysql1229
86d379e203f6        tomcat:8.0          "catalina.sh run"        5 days ago          Up 2 minutes        0.0.0.0:28080->8080/tcp              tomcat1229
5f2f958be986        nginx:1.18          "/docker-entrypoint.…"   5 days ago          Up 2 minutes        0.0.0.0:280->80/tcp                  nginx1229
[root@docker ~]# docker exec -it acb bash
root@acb4983f2d6c:/# mysql -uroot -p123456
mysql> exit
```
{% endspoiler %}
---

### 容器编排
{% spoiler 代码折叠，点击展开 %}
```bash
#编排容器启动顺序
[root@docker docker]# docker rm -f $(docker ps -qa)

[root@docker docker]# vim docker-compose03.yml 
version: "3.6"
services:
        tomcat1:
                image: tomcat:8.0
                ports:
                        - "28080:8080"
                volumes:
                        - tomcatfile1:/usr/local/tomcat
                container_name: tomcat1229
                networks:
                        - docker_test
                depends_on:		#下面写服务名称而非容器名称,意思是让2和3先启动
                        - tomcat2
                        - tomcat3
        tomcat2:
                image: tomcat:8.0
                ports:
                        - "38080:8080"
                volumes:
                        - tomcatfile2:/usr/local/tomcat
                container_name: tomcat1230
                networks:
                        - docker_test
        tomcat3:
                image: tomcat:8.0
                ports:
                        - "48080:8080"
                volumes:
                        - tomcatfile3:/usr/local/tomcat
                container_name: tomcat1231
                networks:
                        - docker_test
volumes:
        tomcatfile1:
        tomcatfile2:
        tomcatfile3:
networks:
        docker_test:
        
 
#启动容器，并从其输出的日志信息中可以观察到，tomcat1 会让 tomcat2 和 tomcat3 先启动，2和3启动一段时间但还未完全启动服务时，tomcat1才开始启动
[root@docker docker]# docker-compose -f docker-compose03.yml up
[+] Running 3/3
 ⠿ Container tomcat1231  Created                                                                                      0.1s
 ⠿ Container tomcat1230  Created                                                                                      0.1s
 ⠿ Container tomcat1229  Created                                                                                      0.1s
Attaching to tomcat1229, tomcat1230, tomcat1231
..................................
```
{% endspoiler %}


---

### docker 离线依赖包下载
{% spoiler 代码折叠，点击展开 %}
```bash
docker 离线依赖包下载方法（全）附Docker的依赖包
yum -y install --downloadonly --downloaddir=/root/docker docker-ce

--downloadonly 只下载不安装   --downloaddir 下载后路径  docker-ce  服务名
```
{% endspoiler %}
