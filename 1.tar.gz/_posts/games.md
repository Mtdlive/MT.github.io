---
title: 游戏推荐
index_img: /img/game.png
banner_img: /img/game.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-12-19 09:13:54
hide: true
category_bar: true
categories:
  - games
tags:
  - games
sticky: 
excerpt: 好玩游戏推荐
---

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

# PC游戏列表

**沙盒类**

```bash
1. 我的世界 (英文名：Minecraft)
2. 
3. 
```

---

**模拟类**

```bash
1. 药剂工艺：炼金术士模拟器 (英文名称：Potion Craft: Alchemist Simulator)
2. 
3. 
```

---

