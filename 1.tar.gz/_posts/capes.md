---
title: 我的世界基岩版
index_img: /img/minecraft.png
banner_img: /img/minecraft.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-12-09 12:13:54
hide: true
category_bar: true
categories:
  - minecraft
tags:
  - minecraft
sticky: 
excerpt: 我的世界基岩版披风导入-联机可见
---

# 我的世界基岩版披风导入-联机可见教程

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

<a class="btn" href="https://pan.baidu.com/s/1vED1pGtWWlXIFWy1u1PaGQ?pwd=p6kv" title="点击跳转">披风文件下载 提取码: p6kv</a>
<a class="btn" href="https://www.bilibili.com/video/BV1hK41197VP/?vd_source=a0a62a5686606302cb0ea2ac2b92dea8" title="点击跳转">视频操作演示</a>

**操作步骤**

```bash
# 当前游戏版本 1.19，旧版本也可以用
# 将压缩包下载到桌面解压，打开IObit程序
# 使用 IObit程序 将游戏文件路径(旧版本显示的不是1.19，而是当前游戏的版本号如1.18、1.17)
C:\Program Files\WindowsApps\Microsoft.MinecraftUWP_1.19.5002.0_x64__8wekyb3d8bbwe\data\skin_packs
下的 persona目录 删掉
# 然后将压缩包内的 persona目录 通过 IObit程序 复制到原游戏路径下
# 启动游戏，打开皮肤菜单，新建皮肤
```

---

**示意图**

![](/img/IObit.png)
![](/img/capes-1.png)

---

**联机注意！**

```bash
1. 一定要关闭游戏设置中的 仅允许受信任的皮肤 的选项
2. 如果游戏内其他玩家无法看到你的自定义披风，其原因有可能是
   对方加载了其他材质包导致的
   对方未关闭游戏设置中的 仅允许受信任的皮肤 的选项
3. 如果你对自定义披风的玩家皮肤感觉不满意，你可以
   打开压缩包内的 persona目录，将steve.png 至 steve16.png 这十七个贴图换成你自己的皮肤，但要保留成原先的名称不变
   然后将压缩包内的 persona目录 通过 IObit程序 重新复制到原游戏路径下
```

![](/img/capes-2.png)

---

**玩家皮肤示意图**

![](/img/steve.png)
![](/img/steve-tt.png)

---

# 我的世界基岩版Toolbox下载及安装教程

* **最新游戏版本 1.19.51**

```bash
加Q群获取: 960874293
```
