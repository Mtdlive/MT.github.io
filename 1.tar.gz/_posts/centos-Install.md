---
title: CentOS安装
index_img: /img/centos.png
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-20 09:34:54
hide: false
category_bar: true
categories:
  - linux
tags:
  - linux
sticky: 1
excerpt: CentOS虚拟机安装操作流程
---

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

@[toc](CentOS安装)

**LINUX**
![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091053644.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

### 获取发行版的途径：
**CentOS**

[官方](https://wiki.centos.org/Download)

[阿里云](http://mirrors.aliyun.com)

[搜狐](http://mirrors.sohu.com)

[网易](http://mirrors.163.com)

[清华源](https://mirrors.tuna.tsinghua.edu.cn/centos/)

**Ubuntu**

[官方](http://cdimage.ubuntu.com/releases/)

---
[vmware workstations15下载链接](https://pan.baidu.com/s/1ll8Y7oAUKoeTf3xHY450LA) 提取码: **bnih**

### CentOS安装步骤：
*  安装 vmware workstations15，并打开
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091135421.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  点击创建新的虚拟机，选择第一个
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091206967.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  下一步
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091240336.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70) 
*  选择你下载的镜像类型，例如：CentOS 7 64位
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091300245.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  给你的虚拟机取一个名字；将虚拟机安装在某个路径。
*  在C/D盘中新建一个文件夹
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091316398.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
* 设置200G，无需担心你的磁盘不足，这里是虚拟磁盘，虚拟机不会立刻占光你的计算机200G。
*  下面选择第一个，然后下一步
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091331974.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  选择CD/dvd;使用IOS镜像文件；浏览并打开你下载的镜像（iso文件）
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091347271.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  确定；开启此虚拟机（第一行是直接安装，第二行是测试ISO文件完整性不进行安装）
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091408182.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  回车
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091434271.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  选择默认English；点击Continue
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091452134.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  点击DATA&TIME；点击上海位置；Done 
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091508907.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  点击SOFTWORK SELECTION；选择GNOME Desktop
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091528616.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  点击INSTALLATION DESTINATION
*  下面的Other Storage Options选择第二个；Done
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921092637820.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  中间选择Standard Partition
*  点击左下角+；分配磁盘空间（具体如何分配可随自己意愿）；Cancel
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921092715237.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  创建如图所示的分区；应注意/data需要手动打出；创建确认点击Add mount point；全部创建完成后点击Done
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921092751108.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  确认无误后点击Accept Changes
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921092911884.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  点击KDUMP；取消Enable kdump；Done
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921093005276.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  点击NETWORK&HOST NAME；左下角修改主机名以便区分；右上角点击显示成ON；Done
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921093052852.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  做完以上工作，点击Begin Installation；点击ROOTPASSWORD，设置管理员密码（两遍）；Done
* ![在这里插入图片描述](https://img-blog.csdnimg.cn/2019092109314353.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
*  点击CREATE USER；设置普通用户全称，用户名，密码（两遍）；Done
----
*  **如果你已完成以上所有操作，那么恭喜你已经完成了99%的安装，剩下的只需等待虚拟机安装完成；最后点击重启（Reboot）即可登录**
*  **根据你的电脑配置，安装所需时间并不相同；但这可能需要不短的时间（也许你可以去喝喝茶什么的？）**
---

![在这里插入图片描述](https://img-blog.csdnimg.cn/20190921091855232.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
###  点击跳至文章尾部
