---
title: CentOS 函数
index_img: 
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-21 13:57:54
hide: false
category_bar: true
categories:
  - linux
tags:
  - linux
sticky: 2
excerpt: CentOS 函数相关操作
---

# **函数**

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

## **函数**

* ```函数由两部分组成 ：函数名和函数体```

* **格式** ：

    * 语法一 ：
```bash   
            f_name (){
            ...函数体...
            }
```

    * 语法二 ：
```bash  
            function f_name {
                ...函数体...
            }
```

    * 语法三 ：
```bash
            function f_name(){
                ...函数体...
            }
```
* 函数function是由若干条shell命令组成的语句块，实现代码重用和模块化编程
* 函数function并不是一个单独的进程，不能独立运行；它是shell程序的一部分
* 函数与shell程序的区别 ：
    
    * shell程序在子shell中运行
    *  函数在当前shell中运行
* 删除shell函数 ：unset function_name

**示例** ：

```bash
#切换至etc目录
    [root@CentOS7 data]# fk(){
    > cd /etc
    > }
    [root@CentOS7 data]# fk
    [root@CentOS7 etc]#
```

```bash
#删除该函数
#或者用户退出系统后，自动删除
    [root@CentOS7 etc]# unset fk
    [root@CentOS7 etc]# fk
    bash: fk: command not found...
    Similar command is: 'fc'
    [root@CentOS7 etc]# 
```
**在脚本中定义及使用函数**

* 函数在使用前必须定义，因此应将函数定义放在脚本开始部分，直至shell首次发现它后才能使用
* 调用函数仅使用其函数名即可

**使用函数检查磁盘最大使用率**
```bash
    [root@CentOS7 etc]# vim max_disk.sh 
    #!/bin/bash
    # Maximum disk occupancy 
    maxdf()
    {
    echo `df -h |grep "^/dev/sd"|tr -s " " |cut -d" " -f5 |sort -n |cut -d"%" -f1 |tail -1`
    }
        echo Maxdf=`maxdf`

    #运行脚本
    [root@CentOS7 etc]# sh max_disk.sh 
    Maxdf=17
```
* 使子进程也可使用 ：
    * ```声明```：export -f function_name
    * ```查看 ```：export -f 或 declare -xf

```bash
    [root@CentOS7 ~]# go(){     #创建一个函数
    > cd /data/scripts/
    > ls
    > \rm *
    > touch firstfun
    > echo {1..9} > firstfun
    > }

    [root@CentOS7 ~]# export -f go  #声明该函数在其子进程依旧有效

    [root@CentOS7 ~]# export -f     #查看函数
    go () 
    { 
        cd /data/scripts/;
        ls --color=auto;
        \rm *;
        touch firstfun;
        echo {1..9} > firstfun
    }
    declare -fx go

    [root@CentOS7 ~]# go    #执行一次该函数
    f1.apk  f2.apk  f3.apk  f4.apk  f5.apk  f6.apk  f7.apk  f8.apk  f9.apk

    [root@CentOS7 scripts]# ls
    firstfun

    [root@CentOS7 scripts]# cat firstfun 
    1 2 3 4 5 6 7 8 9

    [root@CentOS7 scripts]# unset go    #删除该函数

    [root@CentOS7 scripts]# export -f   #重新查看该函数

    [root@CentOS7 scripts]# go      #重新执行该函数
    bash: go: command not found...

    [root@CentOS7 scripts]# export -f go    #重新声明该函数
    -bash: export: go: not a function
```
* **或者**

```bash
[root@CentOS7 scripts]# hello(){
> echo "hello,are you ok?"
> }

[root@CentOS7 scripts]# vim hello_fun.sh
#!/bin/bash
haha(){
hello
}
echo `haha`

[root@CentOS7 scripts]# export -f hello

#运行脚本
[root@CentOS7 scripts]# sh hello_fun.sh
hello,are you ok?
```

* **又或者**

```bash
[root@CentOS7 scripts]# vim one.sh 

#!/bin/bash
one ()
{
echo "let's go to play computer?"
}

[root@CentOS7 scripts]# vim two.sh 

#!/bin/bash
two ()
{
one
three
}
echo "`two`"    #添加" "可保留原有格式，而非打印在同一行

[root@CentOS7 scripts]# vim three.sh

#!/bin/bash
three ()
{
echo "That's good idea."
}
```

* **若未执行 export -f function_name 则会出现 ：**

```bash
#运行脚本
[root@CentOS7 scripts]# sh two.sh 
two.sh: line 3: one: command not found
two.sh: line 4: three: command not found

[root@CentOS7 scripts]# 
```

* **所以**

```bash
[root@CentOS7 scripts]# . one.sh 
[root@CentOS7 scripts]# . three.sh
[root@CentOS7 scripts]# export -f one
[root@CentOS7 scripts]# export -f three

#运行脚本
[root@CentOS7 scripts]# sh two.sh 
let's go to play computer?
That's good idea.
```

* **批量创建用户**

```bash
#准备用户名单
[root@CentOS7 data]# vim name.txt 
lisuo
laowang

[root@CentOS7 data]# vim batch_user2.sh 
#!/bin/bash
. /etc/init.d/functions
if [ "$1" = '-c' ];then
        for USER in `cat /data/name.txt`;do
        if id $USER &> /dev/null;then
action "$USER is exist." false
else
useradd $USER
        echo $USER | passwd --stdin $USER &> /dev/null
action "$USER is created." true
fi
done
        elif [ "$1" = '-r' ];then
for USER in `cat /data/name.txt`;do
userdel -r $USER &> /dev/null
        echo "$USER is removed."
done
else
        echo "Usage: `basename $0` -c |-r "
fi

#运行脚本
[root@CentOS7 data]# sh batch_user2.sh -r
lisuo is removed.
laowang is removed.

#运行脚本
[root@CentOS7 data]# sh batch_user2.sh -c
lisuo is created.                                          [  OK  ]
laowang is created.                                        [  OK  ]
[root@CentOS7 data]# 

#查看执行脚本后是否成功创建用户
[root@CentOS7 data]# cat /etc/passwd
....................................
lisuo:x:1002:1002::/home/lisuo:/bin/bash
laowang:x:1009:1009::/home/laowang:/bin/bash
```

---

**在centos中，函数保存在 `/etc/init.d/functions` 中，在脚本中`调用某函数之前`**
**需要进行其`声明`，否则无法正常调用；系统中除了内置函数之外，用户也也可以编写函数、声明函数、调用函数；**

---

```bash
#过滤搜索action函数关键词与其之后10行显示
[root@C7-3 data]# grep -A10 "^action" /etc/init.d/functions 
action() {
    local STRING rc

    STRING=$1
    echo -n "$STRING "
    shift
    "$@" && success $"$STRING" || failure $"$STRING"
    rc=$?
    echo
    return $rc
}
```
```bash
#删除函数
unset function_name
```
```bash
[root@C7-3 data]# cat test.sh 
#!/bin/bash
. /etc/init.d/functions    #声明函数
if [ $1 = 0 ];then         #$1为脚本名后输入的第一个参数
action "$1 is good!" true  #调用action 打印结果
else
action "$1 is bad!" false
fi
```

```bash
[root@C7-3 data]# bash test.sh 0
0 is good!                                                 [  OK  ]
[root@C7-3 data]# bash test.sh 1
1 is bad!                                                  [FAILED]
```
![](https://img-blog.csdnimg.cn/20200620115608308.png)
