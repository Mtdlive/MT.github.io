---
title: Jumpserver部署
index_img: /img/jumpserver.png
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
hide: false
category_bar: true
categories:
  - linux
  - jumpserver
tags:
  - linux
  - jumpserver
sticky: 4
excerpt: centos jumpserver服务脚本一键部署
date: 2022-12-06 13:55:35
---

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

@[toc](目录)

---
## 参考信息
**当前版本：CentOS7.9**

| 主机 | IP |
| ------- | ------- |
| Jumpserver服务器 | 10.20.0.16 |
| 资产主机 | 10.20.0.15 |

#执行脚本前请确保以下配置达标

{% cb 访问外网正常,true %}
{% cb 内存>=4GB,true %}
{% cb 处理器>=4,true %}
{% cb 硬盘>=50GB,true %}
{% cb 关闭SELINUX,true %}
{% cb 关闭防火墙,true %}

---

#自动化部署脚本`quick_start`内容如下

```bash
#cat quick_start.sh
#!/usr/bin/env bash
#

Version=v2.28.1

function install_soft() {
    if command -v dnf > /dev/null; then
      dnf -q -y install "$1"
    elif command -v yum > /dev/null; then
      yum -q -y install "$1"
    elif command -v apt > /dev/null; then
      apt-get -qqy install "$1"
    elif command -v zypper > /dev/null; then
      zypper -q -n install "$1"
    elif command -v apk > /dev/null; then
      apk add -q "$1"
      command -v gettext >/dev/null || {
      apk add -q gettext-dev python3
    }
    else
      echo -e "[\033[31m ERROR \033[0m] $1 command not found, Please install it first"
      exit 1
    fi
}

function prepare_install() {
  for i in curl wget tar iptables; do
    command -v $i &>/dev/null || install_soft $i
  done
}

function get_installer() {
  echo "download install script to /opt/jumpserver-installer-${Version}"
  cd /opt || exit 1
  if [ ! -d "/opt/jumpserver-installer-${Version}" ]; then
    timeout 60 wget -qO jumpserver-installer-${Version}.tar.gz https://github.com/jumpserver/installer/releases/download/${Version}/jumpserver-installer-${Version}.tar.gz || {
      rm -f /opt/jumpserver-installer-${Version}.tar.gz
      echo -e "[\033[31m ERROR \033[0m] Failed to download jumpserver-installer-${Version}"
      exit 1
    }
    tar -xf /opt/jumpserver-installer-${Version}.tar.gz -C /opt || {
      rm -rf /opt/jumpserver-installer-${Version}
      echo -e "[\033[31m ERROR \033[0m] Failed to unzip jumpserver-installer-${Version}"
      exit 1
    }
    rm -f /opt/jumpserver-installer-${Version}.tar.gz
  fi
}

function config_installer() {
  cd /opt/jumpserver-installer-${Version} || exit 1
  sed -i "s/VERSION=.*/VERSION=${Version}/g" /opt/jumpserver-installer-${Version}/static.env
  ./jmsctl.sh install
  ./jmsctl.sh start
}

function main(){
  if [[ "${OS}" == 'Darwin' ]]; then
    echo
    echo "Unsupported Operating System Error"
    echo "macOS installer please see: https://github.com/jumpserver/Dockerfile"
    exit 1
  fi
  prepare_install
  get_installer
  config_installer
}

main

```

---

## 部署开始

<a class="btn" href="https://github.com/jumpserver/jumpserver/releases/download/v2.28.1/quick_start.sh" title="点击跳转">quick_start.sh</a>


```bash
#若果脚本拉不下来也可以直接复制我上面的 quick_start.sh
[root@C7-6 data]# curl -sSL https://github.com/jumpserver/jumpserver/releases/download/v2.28.1/quick_start.sh
#github里直接复制粘贴的命令有个缺陷，docker未配置加速，拉镜像慢到跑不动了
#建议在执行脚本进行到拉取镜像时手动退出，并配置镜像加速后再重新执行脚本

#将此行加入 /etc/docker/daemon.json
 "registry-mirrors": ["https://dl0ygawi.mirror.aliyuncs.com"],
#记得重启docker
sudo systemctl daemon-reload && sudo systemctl restart docker
```

```bash
[root@C7-6 data]# bash quick_start.sh

……………..# 脚本执行时间很长............
download install script to /opt/jumpserver-installer-v2.28.1


       ██╗██╗   ██╗███╗   ███╗██████╗ ███████╗███████╗██████╗ ██╗   ██╗███████╗██████╗
       ██║██║   ██║████╗ ████║██╔══██╗██╔════╝██╔════╝██╔══██╗██║   ██║██╔════╝██╔══██╗
       ██║██║   ██║██╔████╔██║██████╔╝███████╗█████╗  ██████╔╝██║   ██║█████╗  ██████╔╝
  ██   ██║██║   ██║██║╚██╔╝██║██╔═══╝ ╚════██║██╔══╝  ██╔══██╗╚██╗ ██╔╝██╔══╝  ██╔══██╗
  ╚█████╔╝╚██████╔╝██║ ╚═╝ ██║██║     ███████║███████╗██║  ██║ ╚████╔╝ ███████╗██║  ██║
   ╚════╝  ╚═════╝ ╚═╝     ╚═╝╚═╝     ╚══════╝╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚═╝  ╚═╝

								   Version:  v2.28.1  

1. Check Configuration File
Path to Configuration file: /opt/jumpserver/config
/opt/jumpserver/config/config.txt 	 [ √ ]
/opt/jumpserver/config/nginx/cert/server.crt  	 [ √ ]
/opt/jumpserver/config/nginx/cert/server.key  	 [ √ ]
complete

>>> Install and Configure Docker
1. Install Docker
complete

2. Configure Docker
complete

3. Start Docker
complete

>>> Loading Docker Image
[jumpserver/redis:6.2]
6.2: Pulling from jumpserver/redis
a603fa5e3b41: Pull complete 
77631c3ef092: Pull complete 
ed3847cf62b8: Pull complete 
c35fa6b24d23: Pull complete 
715a5ac967d7: Pull complete 
0a26dfd13d55: Pull complete 
Digest: sha256:a6349e1a6a8b317dbd9e196eb3f4c44b304f7fb899e7d2af7b0211112bccd952
Status: Downloaded newer image for jumpserver/redis:6.2
docker.io/jumpserver/redis:6.2
..............................................
#此处提示是否自动以自定义设置服务相关信息,看个人喜好设置
Digest: sha256:a7065804f135f3d1fef15412adec99d62475e42e48c0ec6934d7fc4b44aae1ad
Status: Downloaded newer image for jumpserver/web:v2.28.1
docker.io/jumpserver/web:v2.28.1

complete

>>> Install and Configure JumpServer
1. Configure Private Key
SECRETE_KEY:     ZjQzODRkNTYtNTY1Ny1hNTIyLTBlMmYtNzEzMDVmYTNlZDZk
BOOTSTRAP_TOKEN: ZjQzODRkNTYtNTY1Ny1hNTIy
complete

2. Configure Persistent Directory
Do you need custom persistent store, will use the default directory /data/jumpserver? (y/n)  (default n): n
complete

3. Configure MySQL
Do you want to use external MySQL? (y/n)  (default n): n
complete

4. Configure Redis
Do you want to use external Redis? (y/n)  (default n): n
complete

5. Configure External Port
Do you need to customize the JumpServer external port? (y/n)  (default n): 
.................................
#当出现此行时表示安装成功，访问地址和账户信息以打印在下方
>>> The Installation is Complete
1. You can use the following command to start, and then visit
cd /opt/jumpserver-installer-v2.28.1
./jmsctl.sh start

2. Other management commands
./jmsctl.sh stop
./jmsctl.sh restart
./jmsctl.sh backup
./jmsctl.sh upgrade
For more commands, you can enter ./jmsctl.sh --help to understand

3. Web access
http://192.168.40.150:80
Default username: admin  Default password: admin

4. SSH/SFTP access
ssh -p2222 admin@192.168.40.150
sftp -P2222 admin@192.168.40.150

5. More information
Official Website: https://www.jumpserver.org/
Documentation: https://docs.jumpserver.org/


[+] Running 8/8
 ⠿ Container jms_redis   Healthy                                                                                          2.0s
 ⠿ Container jms_mysql   Healthy                                                                                          2.0s
 ⠿ Container jms_core    Healthy                                                                                         28.7s
 ⠿ Container jms_web     Started                                                                                         29.5s
 ⠿ Container jms_celery  Started                                                                                         29.5s
 ⠿ Container jms_lion    Started                                                                                         29.7s
 ⠿ Container jms_koko    Started                                                                                         29.7s
 ⠿ Container jms_magnus  Started                                                                                         42.3s
```

---
#登录 jumpserver web 界面 ，账户在上图可看
#创建普通用户
![](https://img-blog.csdnimg.cn/20200703155615702.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
![](https://img-blog.csdnimg.cn/20200703155637153.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

---
#创建管理用户
#管理用户应当是资产主机上的root管理员或者是在资产主机上拥有 `NOPASSWD: ALL sudo` 权限的用户
#jumpserver会使用该用户去推送系统用户以及获取资产硬件信息等，因此若该用户的密钥配置错误将会导致无法连接资产主机
![](https://img-blog.csdnimg.cn/20200703155755546.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

---
#创建系统用户
#该用户是jumpserver跳转登录资产主机时使用的用户
![](https://img-blog.csdnimg.cn/20200703155838607.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
![](https://img-blog.csdnimg.cn/20200703155853724.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

---
#创建资产
![](https://img-blog.csdnimg.cn/20200703155932353.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
![](https://img-blog.csdnimg.cn/20200703155946436.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

![](https://img-blog.csdnimg.cn/20200703160009759.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

---
#资产授权
![](https://img-blog.csdnimg.cn/20200703160028355.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
![](https://img-blog.csdnimg.cn/20200703160051251.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

---
#登录mahuateng 用户
![](https://img-blog.csdnimg.cn/20200703160114330.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

![](https://img-blog.csdnimg.cn/20200703160124821.png)

---
#返回admin用户，配置命令过滤
![](https://img-blog.csdnimg.cn/20200703160146362.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

![](https://img-blog.csdnimg.cn/20200703160152961.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

![](https://img-blog.csdnimg.cn/20200703160201839.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

![](https://img-blog.csdnimg.cn/2020070316021226.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

---
#更新系统用户配置
![](https://img-blog.csdnimg.cn/20200703160224699.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)

![](https://img-blog.csdnimg.cn/20200703160231968.png)
![](https://img-blog.csdnimg.cn/20200703160240440.png)

---
#登录mahuateng 用户
![](https://img-blog.csdnimg.cn/20200703160301579.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2R1c2hhbnNhbw==,size_16,color_FFFFFF,t_70)
