---
title: K8S单机部署
index_img: /img/k8s.png
banner_img: /img/sbpk.jpg
banner_img_height: 100
banner_mask_alpha: 0.3
date: 2022-10-27 14:43:54
hide: false
category_bar: true
categories:
  - k8s
  - docker
tags:
  - k8s
  - docker
sticky: 5
excerpt: K8S单机部署相关内容
---

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

# K8S单机部署

```html
准备工作：创建一/三台CentOS7虚拟机，无需进行任何额外操作
确保虚拟机能够ping通外部网络，将k8s镜像文件上传到虚拟机中
```
**k8s镜像文件下载地址：**
<a class="btn" href="https://pan.baidu.com/s/1ax56iA3h4uSmydzZz-BjCA?pwd=pe8a" title="https://pan.baidu.com/s/1ax56iA3h4uSmydzZz-BjCA?pwd=pe8a">点击下载 [提取码: pe8a]</a>
---

**`vim master_install.sh`**
{% spoiler 代码折叠，点击展开 %}
```bash
#!/bin/bash

# 提示信息
echo "脚本仅适用于X86_64 CentOS7.6"

IP=`ip a | egrep "ens33" | grep "inet" | awk '{print $2}' | awk -F"/" '{print $1}'`

# 关闭SELINUX
setenforce 0 && sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config

# 关闭防火墙
systemctl stop firewalld
systemctl disable firewalld

# 设置hostname
hostnamectl --static set-hostname master1
echo -e "${IP} master1" >> /etc/hosts

# 修改内核参数和模块
cat <<EOF > /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

# 使内核参数配置生效
sysctl --system
modprobe br_netfilter
lsmod | grep br_netfilter

# 关闭交换内存，如果不关闭，kubelet服务将无法启动
swapoff -a && sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

# 基础命令检测
rpm -qa|grep unzip &> /dev/null
if [ "$?" -ne "0" ];then
	yum install unzip -y
fi

# 安装Docker
yum -y install yum-utils device-mapper-persistent-data lvm2
sleep 2
#yum-config-manager -y --add-repo https://download.docker.com/linux/centos/docker-ce.repo
yum-config-manager --add-repo  http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

if [ "$?" -ne "0" ];then
	echo "docker repo 导入失败，请重新执行"
	exit 233;
fi

yum install docker-ce -y && systemctl restart docker && systemctl enable docker

# 设置国内docker仓库
cat <<EOF > /etc/docker/daemon.json
{
  "registry-mirrors": [
    "https://3laho3y3.mirror.aliyuncs.com"
  ],
  "exec-opts": [
    "native.cgroupdriver=systemd"
  ]
}
EOF
systemctl restart docker
sleep 2

# 配置kubernetes yum源，用以安装Kubernetes基础服务及工具，此处使用阿里云镜像仓库源
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64/
enabled=1
gpgcheck=0
repo_gpgcheck=0
gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
EOF
sleep 2

# 安装Kubernetes基础服务及工具
yum -y install kubelet-1.23.6 kubeadm-1.23.6 kubectl-1.23.6

if [ "$?" -ne "0" ];then
	echo "k8s下载失败，请重新执行"
	exit 244;
fi

sed -i 's@kubeconfig=/etc/kubernetes/kubelet.conf@kubeconfig=/etc/kubernetes/kubelet.conf --cgroup-driver=systemd@' /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf
#systemctl daemon-reload && systemctl restart kubelet && systemctl enable kubelet.service

# 查看k8s相关镜像
# kubeadm config images list

# 镜像下载脚本
#images=(
#k8s.gcr.io/kube-apiserver:v1.23.6
#k8s.gcr.io/kube-controller-manager:v1.23.6
#k8s.gcr.io/kube-scheduler:v1.23.6
#k8s.gcr.io/kube-proxy:v1.23.6
#k8s.gcr.io/pause:3.6
#k8s.gcr.io/etcd:3.5.1
#)
#for i in ${images[@]}; do 
#  imageName=${i#k8s.gcr.io/}
#  docker pull registry.aliyuncs.com/google_containers/$imageName
#  docker tag registry.aliyuncs.com/google_containers/$imageName k8s.gcr.io/$imageName
#  docker rmi registry.aliyuncs.com/google_containers/$imageName
#done;

# 导入离线k8s镜像,若使用离线镜像，需将下列注释取消

unzip k8s_1.23.6.zip 
docker load -i k8s_1.23.6/coredns_v1.8.6.tar
docker load -i k8s_1.23.6/etcd_3.5.3-0.tar
docker load -i k8s_1.23.6/kube-apiserver_v1.23.6.tar
docker load -i k8s_1.23.6/kube-controller-manager_v1.23.6.tar
docker load -i k8s_1.23.6/kube-proxy_v1.23.6.tar
docker load -i k8s_1.23.6/kube-scheduler_v1.23.6.tar
docker load -i k8s_1.23.6/pause_3.6.tar
docker load -i k8s_1.23.6/calico_cni.tar
docker load -i k8s_1.23.6/calico_kube.tar
docker load -i k8s_1.23.6/calico_node.tar

if [ "$?" -ne "0" ];then
	echo "未成功解压压缩包，请重新执行"
	exit 255;
fi

# 初始化k8s和网络
# kubeadm init --kubernetes-version=v1.23.6 --pod-network-cidr=192.168.0.0/16
kubeadm init --kubernetes-version=v1.23.6 \
--pod-network-cidr=192.168.0.0/16 \
--apiserver-advertise-address=${IP} \
--service-cidr=172.20.0.0/20 \
--ignore-preflight-errors='swap' \
--image-repository=registry.cn-hangzhou.aliyuncs.com/google_containers

if [ "$?" -ne "0" ];then
	echo "k8s初始化异常退出！"
	exit 266;
else
	systemctl daemon-reload && systemctl restart kubelet && systemctl enable kubelet.service

# 初始化kubectl配置
	mkdir -p $HOME/.kube
	sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
	sudo chown $(id -u):$(id -g) $HOME/.kube/config
#	kubectl apply -f https://cloud.weave.works/k8s/net?k8s-version=$(kubectl version | base64 | tr -d '\n')
kubectl apply -f k8s_1.23.6/calico.yaml
# kubectl apply -f https://docs.projectcalico.org/manifests/calico.yaml

# 默认k8s的master节点是不能跑pod的业务，需要执行以下命令解除限制
	# kubectl taint nodes --all node-role.kubernetes.io/master-

# 查看主节点运行 Pod 的状态
	kubectl get pods --all-namespaces -o wide
fi

```
{% endspoiler %}
---

**`vim worker_install.sh`**
{% spoiler 代码折叠，点击展开 %}
```bash
#!/bin/bash

# 提示信息
echo "脚本仅适用于X86_64 CentOS7.6"

IP=`ip a | egrep "ens33" | grep "inet" | awk '{print $2}' | awk -F"/" '{print $1}'`

# 关闭SELINUX
setenforce 0 && sed -i "s/SELINUX=enforcing/SELINUX=disabled/g" /etc/selinux/config

# 关闭防火墙
systemctl stop firewalld
systemctl disable firewalld

# 设置hostname
hostnamectl --static set-hostname worker1
echo -e "${IP} worker1" >> /etc/hosts

# 修改内核参数和模块
cat <<EOF > /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-ip6tables = 1
net.bridge.bridge-nf-call-iptables = 1
EOF

# 使内核参数配置生效
sysctl --system
modprobe br_netfilter
lsmod | grep br_netfilter

# 关闭交换内存，如果不关闭，kubelet服务将无法启动
swapoff -a && sed -i '/ swap / s/^\(.*\)$/#\1/g' /etc/fstab

# 基础命令检测
rpm -qa|grep unzip &> /dev/null
if [ "$?" -ne "0" ];then
	yum install unzip -y
fi

# 安装Docker
yum -y install yum-utils device-mapper-persistent-data lvm2
sleep 2
#yum-config-manager -y --add-repo https://download.docker.com/linux/centos/docker-ce.repo
yum-config-manager --add-repo  http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo

if [ "$?" -ne "0" ];then
	echo "docker repo 导入失败，请重新执行"
	exit 233;
fi

yum install docker-ce -y && systemctl restart docker && systemctl enable docker

# 设置国内docker仓库
cat <<EOF > /etc/docker/daemon.json
{
  "registry-mirrors": [
    "https://3laho3y3.mirror.aliyuncs.com"
  ],
  "exec-opts": [
    "native.cgroupdriver=systemd"
  ]
}
EOF
systemctl restart docker
sleep 2

# 配置kubernetes yum源，用以安装Kubernetes基础服务及工具，此处使用阿里云镜像仓库源
cat <<EOF > /etc/yum.repos.d/kubernetes.repo
[kubernetes]
name=Kubernetes
baseurl=https://mirrors.aliyun.com/kubernetes/yum/repos/kubernetes-el7-x86_64/
enabled=1
gpgcheck=0
repo_gpgcheck=0
gpgkey=https://mirrors.aliyun.com/kubernetes/yum/doc/yum-key.gpg https://mirrors.aliyun.com/kubernetes/yum/doc/rpm-package-key.gpg
EOF
sleep 2

# 安装Kubernetes基础服务及工具
yum -y install kubelet-1.23.6 kubeadm-1.23.6 kubectl-1.23.6

if [ "$?" -ne "0" ];then
	echo "k8s下载失败，请重新执行"
	exit 244;
fi

sed -i 's@kubeconfig=/etc/kubernetes/kubelet.conf@kubeconfig=/etc/kubernetes/kubelet.conf --cgroup-driver=systemd@' /usr/lib/systemd/system/kubelet.service.d/10-kubeadm.conf

# 导入离线k8s镜像,若master使用了离线镜像部署，则此处下方需要注释
unzip k8s_1.23.6.zip 
docker load -i k8s_1.23.6/coredns_v1.8.6.tar
docker load -i k8s_1.23.6/etcd_3.5.3-0.tar
docker load -i k8s_1.23.6/kube-apiserver_v1.23.6.tar
docker load -i k8s_1.23.6/kube-controller-manager_v1.23.6.tar
docker load -i k8s_1.23.6/kube-proxy_v1.23.6.tar
docker load -i k8s_1.23.6/kube-scheduler_v1.23.6.tar
docker load -i k8s_1.23.6/pause_3.6.tar
docker load -i k8s_1.23.6/calico_cni.tar
docker load -i k8s_1.23.6/calico_kube.tar
docker load -i k8s_1.23.6/calico_node.tar

if [ "$?" -ne "0" ];then
	echo "未成功解压压缩包，请重新执行"
	exit 255;
fi

systemctl daemon-reload && systemctl restart kubelet && systemctl enable kubelet.service

echo "请手动输入master token添加节点命令"
```
{% endspoiler %}
