---
title: Docker Images
index_img: /img/docker.png
banner_img: /img/sbpk.jpg
banner_img_height: 90
banner_mask_alpha: 0.3
date: 2022-10-25 14:28:54
hide: false
category_bar: true
categories:
  - docker
tags:
  - docker
sticky: 4
excerpt: Docker images 导入、导出等相关操作

---

# Docker images

<p id="hitokoto">获取中...</p>
<script src="https://v1.hitokoto.cn/?encode=js&select=%23hitokoto" defer></script>

---

{% spoiler 代码折叠，点击展开 %}
```bash
#基于现有的容器制作镜像
docker commit -a "提交的镜像作者" -m "提交时的说明文字" 容器id 镜像名称:自定义版本号
示例：
docker commit -a 'Mtdia' -m 'web-01' 0895cb579748 tomcat:v1.0


#将docker镜像导出
docker save 镜像ID > 导出后的tar包名称
示例：
docker save ae513a47849c > nginx-save.tar

#另一种写法
docker save -o 导出后的tar包名称 镜像ID
示例：
docker save -o nginx-save.tar ae513a47849c


#导出时保留原镜像ID和tag
docker save -o test.tar 原镜像ID:tag


#将docker镜像导入
docker save -o nginx-save.tar 


#修改现存镜像tag
docker tag  镜像ID  新镜像名称:tag


#容器的导出与导入
#导出
docker export -o mysql-`date +%Y%m%d`.tar 220aee82cfea


#导入
docker import  my_ubuntu_v3.tar runoob/ubuntu:v4
```
{% endspoiler %}
---
{% spoiler 代码折叠，点击展开 %}
```html
#解释
镜像和容器 导出和导入的区别:
1.镜像导入 是复制的过程
2.容器导入 是将当前容器 变成一个新的镜像
save 和 export区别：
1）save 保存镜像所有的信息-包含历史
2）export 只导出当前的信息
```
{% endspoiler %}
